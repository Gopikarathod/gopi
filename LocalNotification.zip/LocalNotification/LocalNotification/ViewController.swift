//
//  ViewController.swift
//  LocalNotification
//
//  Created by agile-10 on 29/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController ,UNUserNotificationCenterDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        
        center.getNotificationSettings { (setting) in
            if (setting.authorizationStatus == .denied){
                print(setting.authorizationStatus.rawValue)
                DispatchQueue.main.async{
                    UIApplication.shared.open(URL(string:UIApplicationOpenSettingsURLString)!)
                    checkPermission()
                }
            }else{
                checkPermission()
            }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
   /* func registerationNotification(application:UIApplication) -> Void{
        
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        center.requestAuthorization(options: [.sound,.alert,.badge], completionHandler: { (genret, error) in
            if genret{
                
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                    }
                }
            })
    }*/
   
    
    func checkPermission(){
    
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        center.requestAuthorization(options: [.alert,.sound,.badge], completionHandler: { (genret, error) in
                    if genret {
                        DispatchQueue.main.async {
                            self.testnotification()
                        }
                    }else{
                        print(error?.localizedDescription ?? "")
                    }
                })
        
        }
       
    }
    
    
    func testnotification(){
    
        let date  = Date.init(timeIntervalSinceNow: 60)
        let dateformatt:DateFormatter = DateFormatter()
        dateformatt.dateFormat = "yyyy-MM-dd hh:mm:ss z"
        let strname:String = dateformatt.string(from: date)
        
        let content = UNMutableNotificationContent()
        content.title = "NotificationTitle"
        content.subtitle = "NotificationSubTitle"
        content.body = "NotificationBody"
        content.badge = 5
        content.sound = UNNotificationSound.default()
        
        let triggerDate = Calendar.current.dateComponents([.day,.month,.year,.hour,.minute,.second], from: date)
        let trigger = UNCalendarNotificationTrigger.init(dateMatching: triggerDate, repeats: false)
        
        ///GetPending Notification List

        UNUserNotificationCenter.current().getPendingNotificationRequests(completionHandler: { (notification) in
            
            for n in notification{
                print(n.identifier)
                }
            })
        
        let request = UNNotificationRequest.init(identifier: "\(strname)", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().add(request) { (error) in
            if error != nil{
               // print(error?.localizedDescription)
            }
        }
        
    }
    
  /*  private func registerForNotification() {
        //Requesting Authorization for User Interactions
        if #available(iOS 10.0, *) {
            let center = UNUserNotificationCenter.current()
            
            center.requestAuthorization(options: [.alert, .sound]) { (granted, error) in
                // Enable or disable features based on authorization.
                if granted {
                    // print("granted")
                    
                } else {
                    // print("denied")
                }
            }
        }
        else
        {  UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.sound, .alert], categories: nil))
        }
    }*/
    
   /* func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print(response.notification)
    }*/

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

