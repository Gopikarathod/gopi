//
//  CollectionViewCell.swift
//  Filemanager
//
//  Created by agile-10 on 26/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var myImage:UIImageView!
    
}
