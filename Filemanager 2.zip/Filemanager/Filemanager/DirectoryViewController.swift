//
//  DirectoryViewController.swift
//  Filemanager
//
//  Created by agile-10 on 31/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class DirectoryViewController: UIViewController {
    
   @IBOutlet var txtdirectory:UITextField!
    var txtStr:String = ""
    let objapp = UIApplication.shared.delegate as? AppDelegate
    var dict:[String] = []
    var directoryPath:String!
     let  pathDirectory = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    // Do any additional setup after loading the view.
    }
    func Path(){
        
        
            if ((objapp?.strPath)?.isEmpty)!{
                directoryPath = pathDirectory.appending("/\(txtStr)")
            }else{
                print(objapp?.strPath ?? "")
                directoryPath = (objapp?.strPath)?.appending("/\(txtStr)")
            }
    

            do{
                
                if !FileManager.default.fileExists(atPath: directoryPath){
                
                    try FileManager.default.createDirectory(atPath: directoryPath, withIntermediateDirectories: false , attributes: nil)
                    
                } else{
                    print("Already")
                }
                
                if (objapp?.strPath.isEmpty)!{
                   dict =
                    try FileManager.default.contentsOfDirectory(atPath:pathDirectory)
                    
                }else{
                
                    dict =
                        try FileManager.default.contentsOfDirectory(atPath:(objapp?.strPath)!)
                    
                }
                    print(dict)
                    objapp?.arrFileManager = dict
                    UserDefaults.standard.set(dict, forKey: "Filemanager")
                    UserDefaults.standard.synchronize()

                print(directoryPath)
            }catch{
                print(error.localizedDescription)
            }
        
        
        
        
    }
    
    
    @IBAction func btnCreate(){
        
        if (txtdirectory.text?.isEmpty)!{
            
            let alertvc:UIAlertController = UIAlertController.init(title: "Error", message: "Enter data", preferredStyle:UIAlertControllerStyle.alert)
            if (txtdirectory.text?.isEmpty)!{
                let altbdate:UIAlertAction = UIAlertAction.init(title: "Enter Directory Name", style: UIAlertActionStyle.default) { (action) in
                    print("Enter data in txtdirecotry")
                }
                alertvc.addAction(altbdate)
                self.present(alertvc, animated: true, completion: nil)
            }
            
        }else{
            txtStr = txtdirectory.text!
            Path()
        }
 

        txtdirectory.text = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
