//
//  CollectionViewController.swift
//  Filemanager
//
//  Created by agile-10 on 26/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class CollectionViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate{
    
    @IBOutlet var collectionView:UICollectionView!
    
    var arrImg:[[String:Any]] = []
    var arrtemp:[[String:Any]] = []
    let objapp = UIApplication.shared.delegate as! AppDelegate
 //   let objfile:FileManagerViewController = FileManagerViewController()
    let objdirectory:DirectoryViewController = DirectoryViewController()
    var filePath:String!
    var objpath:String!


    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.dataSource = self
        collectionView.delegate = self
        
        imageDictionary(withNameImage: "1.jpg", withIsSelected: false)
        imageDictionary(withNameImage: "2.jpg", withIsSelected: false)
        imageDictionary(withNameImage: "3.png", withIsSelected: false)
        imageDictionary(withNameImage: "5.jpg", withIsSelected: false)
        imageDictionary(withNameImage: "6.jpg", withIsSelected: false)
        imageDictionary(withNameImage: "7.jpeg", withIsSelected: false)
        imageDictionary(withNameImage: "8.jpg", withIsSelected: false)
        imageDictionary(withNameImage: "9.jpg", withIsSelected: false)
        
        objpath = objdirectory.pathDirectory
        // Do any additional setup after loading the view.
    }
    
    func imageDictionary(withNameImage image:String,withIsSelected selected:Bool){
        let dict:[String:Any] = ["name":image,"isSelected":selected]
        arrImg.append(dict)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print(arrImg)
        return arrImg.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
          let cell:CollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        
        var objarr = arrImg[indexPath.row]
        let objimg = objarr["name"]
        let objIsSelect:Bool = objarr["isSelected"] as! Bool
        
        cell.myImage.image = UIImage.init(named: objimg as! String)

        if objIsSelect == true{
            cell.myImage.layer.borderWidth =  1.0
            cell.myImage.layer.borderColor = UIColor.red.cgColor
        }else{
            cell.myImage.layer.borderWidth =  1.0
            cell.myImage.layer.borderColor = UIColor.black.cgColor
        }
        
        return cell
    
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var imgSelect = arrImg[indexPath.row]
        var objSelected:Bool = (imgSelect["isSelected"] as? Bool)!
        
        if objSelected == false{
            objSelected = true
        }else{
            objSelected = false
        }
        imgSelect.updateValue(objSelected, forKey: "isSelected")
        arrImg[indexPath.row] = imgSelect
        collectionView.reloadData()
    }
    
    func saveImage(){
        
        for i in arrtemp{
            let objImg:String = i["name"] as! String
            print(objImg)
            let aryName:[String] = objImg.components(separatedBy: ".");
            
            guard let strFileName = aryName.first else {
                return
            }
            guard let strFileExtenstion = aryName.last else {
                return
            }
            
            if let bundlePAth:String  = Bundle.main.path(forResource: strFileName , ofType: strFileExtenstion)
            {
                if (objapp.strPath.isEmpty){
                    
                    filePath = objpath.appending("/\(strFileName).\(strFileExtenstion)")
                }else {
                     filePath = (objapp.strPath).appending("/\(strFileName).\(strFileExtenstion)")
                }
                
                
                do{
                    
                    if !FileManager.default.fileExists(atPath: filePath){
                        try FileManager.default.copyItem(atPath: bundlePAth , toPath: filePath)
                        print("save")
                    }
                    
                    if (objapp.strPath.isEmpty){
                        let _:[String] = try FileManager.default.contentsOfDirectory(atPath:objpath)
                    }else{
                        let _:[String] = try FileManager.default.contentsOfDirectory(atPath:objapp.strPath)
                    }
                    
                }
                catch {
                    print(error.localizedDescription)
                }
                
            }
        }
    }

    @IBAction func btnSave(_ sender: UIButton) {
        
        for i in arrImg{
            let objselect:Bool = i["isSelected"] as! Bool
            if objselect == true{
                arrtemp.append(i)
            }else{
                
                if arrtemp.isEmpty{
                    let alertvc:UIAlertController = UIAlertController.init(title: "Error", message: "No Selected Any Image", preferredStyle:UIAlertControllerStyle.alert)
                    if (arrtemp.isEmpty){
                        let selectImg:UIAlertAction = UIAlertAction.init(title: "Select Image", style: UIAlertActionStyle.default) { (action) in
                            print("Select Img")
                        }
                        alertvc.addAction(selectImg)
                        self.present(alertvc, animated: true, completion: nil)
                    }
                    
                }
            }
        }
        saveImage()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
