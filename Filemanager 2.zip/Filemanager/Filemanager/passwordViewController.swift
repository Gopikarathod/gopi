//
//  passwordViewController.swift
//  Filemanager
//
//  Created by agile-10 on 21/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import CoreData

class passwordViewController: UIViewController {
    
    @IBOutlet var lblname:UILabel!
    @IBOutlet var lblname2:UILabel!
    @IBOutlet var txtpass:UITextField!
    @IBOutlet var txtpass2:UITextField!
    var nameDirectory:String!
    var dict:[String:Any] = [:]
    var arrpass:[[String:Any]] = []
    
    @IBAction func dsad(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchDataInDatabuse()
        for i in arrpass{
            let namae = i["directoryname"] as? String
            if nameDirectory == namae{
                lblname2.isHidden = true
                txtpass2.isHidden = true
            }
        }
            lblname.text = "Password"
            lblname2.text = "ConfPssd"
        
    
        // Do any additional setup after loading the view.
    }
    
    
    
    func fetchDataInDatabuse(){
        
        guard  let objapp = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managecontext = objapp.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Password")
        
        do{
            let data = try managecontext.fetch(fetchRequest)
            
            for user in data {
                
                dict["new"] = user.value(forKey: "new")
                dict["conform"] = user.value(forKey: "conform")
                dict["directoryname"] = user.value(forKey: "directoryname")
                arrpass.append(dict)
                
            }
            
            
        } catch{
            print(error.localizedDescription)
        }
    }
    
    
    func insertData(){
        guard let objapp = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
      //  let name = objapp.strPath.split(separator: "/")
        //let Direcotyname = name.last
        
        dict = ["New":txtpass.text ?? "","Conform":txtpass2.text ?? "","directoryname":nameDirectory]
        
        let managecontext = objapp.persistentContainer.viewContext
        let entity:NSEntityDescription = NSEntityDescription.entity(forEntityName: "Password", in: managecontext)!
        let attribute:NSManagedObject = NSManagedObject.init(entity: entity, insertInto: managecontext)
        
        attribute.setValue(dict["Conform"], forKey: "conform")
        attribute.setValue(dict["directoryname"], forKey: "directoryname")
        attribute.setValue(dict["New"], forKey: "new")
        
        do{
            try managecontext.save()
            print("save Data")
            self.dismiss(animated: true, completion: nil)
        }catch{
            print(error.localizedDescription)
        }
    }

    @IBAction func btnDone(_ sender: UIButton) {
        
        
        
        if (txtpass.text?.isEmpty)! || (txtpass2.text?.isEmpty)!{
            print("Enter PassWord")
            txtpass2.text = ""
            txtpass.text = ""
        }else{
           
            if (txtpass.text != txtpass2.text){
                print("password and conformpassword Not Same")
            }else{
            fetchDataInDatabuse()
            
            for i in arrpass{
                let objpass:String = i["new"] as! String
                let objconfpass:String = i["conform"] as! String
                let objdirectory:String = i["directoryname"] as! String
                
                if (txtpass.text == objpass) || (txtpass2.text == objconfpass) {
                      self.dismiss(animated: true, completion: nil)
                        } else{
                    
                            if objdirectory == nameDirectory {
                                print("Enter correct password")
                            }else{
                                insertData()
                        }
                    }
                }
            }
        }
    }
    
    @IBAction func btnREset(_ sender: UIButton) {
        
        lblname.text  = "OldPassword"
        lblname2.text = "NewPassword"
        
        if (lblname.text == "OldPassword"){
            fetchDataInDatabuse()
            
            for i in arrpass{
                let objpass:String = i["new"] as! String
                if (txtpass.text == objpass){
                    updateRecored(withString: txtpass2.text!)
                    print("savedata")
                }else{
                    print("old password wrong")
                }
            }
            txtpass.becomeFirstResponder()

        }
        
    }
    
    func updateRecored(withString txtpass:String){
        
        
        guard  let objapp = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managecontext = objapp.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Password")
        fetchRequest.predicate = NSPredicate.init(format: "directoryname = %@", nameDirectory)
        
        do{
            let data = try managecontext.fetch(fetchRequest)
            
            for user in data {
                
                user.setValue(txtpass, forKey: "new")
                user.setValue(txtpass, forKey: "conform")
            }
            
               try managecontext.save()
            
        } catch{
            print(error.localizedDescription)
        }

        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
