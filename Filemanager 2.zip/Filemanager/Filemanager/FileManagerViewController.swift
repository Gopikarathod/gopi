//
//  FileManagerViewController.swift
//  Filemanager
//
//  Created by agile-10 on 31/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class FileManagerViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{
    
    @IBOutlet var tblfilemanager:UITableView!
    @IBOutlet var lblMasseg:UILabel!
    var objappDelegate = UIApplication.shared.delegate  as! AppDelegate
    var selectDirectory = ""
    var selectedPath:String!
    var path:String!
    let objrefresh:UIRefreshControl = UIRefreshControl()
    let objdirecotry:DirectoryViewController = DirectoryViewController()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblfilemanager.dataSource = self
        tblfilemanager.delegate = self
        

        
        objdirecotry.Path()
        path = objdirecotry.pathDirectory
        checkDirectoryNil()
        objrefresh.addTarget(self, action: #selector(refresh), for: .valueChanged)
        tblfilemanager.refreshControl = objrefresh
        
        if ((objappDelegate.strPath).isEmpty){
            self.title = "FileManager"
        }else{
            self.title = "\(objappDelegate.selectTitle)"
        }

               // Do any additional setup after loading the view.
    }
    
    func checkDirectoryNil(){
        if (objappDelegate.arrFileManager.count) == 0 || (objappDelegate.arrFileManager == [".DS_Store"]){
            lblMasseg.text = "No Directory"
        }else{
            lblMasseg.text = ""
        }
    }

    @objc func refresh(){
        
            objdirecotry.Path()
            checkDirectoryNil()
            tblfilemanager.reloadData()
            tblfilemanager.refreshControl?.endRefreshing()

    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
            return objappDelegate.arrFileManager.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let objpass:passwordViewController = passwordViewController()
        let cell:FilemanagerCell = (tableView.dequeueReusableCell(withIdentifier: "FilemanagerCell") as? FilemanagerCell)!
        cell.accessoryType = UITableViewCellAccessoryType.disclosureIndicator
        cell.lbl.text = objappDelegate.arrFileManager[indexPath.row]
        objpass.fetchDataInDatabuse()
        cell.btn.tag = indexPath.row
        cell.btn.addTarget(self, action: #selector(btnpass), for: .touchUpInside)
        
        if(objpass.arrpass.isEmpty)
        {
            cell.btn.setImage(UIImage.init(named: "unlock.png"), for: .normal)
        }
        else
        {
        for i in objpass.arrpass
        {
            let name1 = objappDelegate.arrFileManager[indexPath.row]

            if(i.isEmpty)
            {
                cell.btn.setImage(UIImage.init(named: "unlock.png"), for: .normal)
            }
            else{
                let name = i["directoryname"] as! String
                    if(name1 == name)
                    {
                        cell.btn.setImage(UIImage.init(named: "lock.png"), for: .normal)
                        return cell
                    }
                    else
                    {
                        cell.btn.setImage(UIImage.init(named: "unlock.png"), for: .normal)
                    }
                }
            }
        }

        
       
        return cell
        
    }
    @IBAction func btnpass(sender : UIButton)
   {
    let objpass:passwordViewController = passwordViewController()
    objpass.fetchDataInDatabuse()
        if let superview = sender.superview, let cell = superview.superview as? FilemanagerCell {
            if let indexpath1 = tblfilemanager.indexPath(for: cell){
            let item = objappDelegate.arrFileManager[indexpath1.row]
                
                if(objpass.arrpass.isEmpty)
                {
                    let objpassword:passwordViewController = (storyboard?.instantiateViewController(withIdentifier: "passwordViewController") as? passwordViewController)!
                    objpassword.nameDirectory = item
                    self.present(objpassword, animated: true, completion: nil)
                }
                else
                {
                    for i in objpass.arrpass
                    {
                            if(i.isEmpty)
                            {
                                let objpassword:passwordViewController = (storyboard?.instantiateViewController(withIdentifier: "passwordViewController") as? passwordViewController)!
                                objpassword.nameDirectory = item
                                self.present(objpassword, animated: true, completion: nil)
                                
                            }
                            else
                            {
                                let name = i["directoryname"] as! String
                                let name1 = item
            
                                if(name1 == name)
                                {
                
                                }
                                else
                                {
                                    let objpassword:passwordViewController = (storyboard?.instantiateViewController(withIdentifier: "passwordViewController") as? passwordViewController)!
                                    objpassword.nameDirectory = item
                                    self.present(objpassword, animated: true, completion: nil)
                                }
                        }
                    }
                }
            }
        }
    
    }
   
    
    @IBAction func btnplus(){
        let objdirectory:DirectoryViewController = (storyboard?.instantiateViewController(withIdentifier: "DirectoryViewController") as? DirectoryViewController)!
        
        self.navigationController?.pushViewController(objdirectory, animated: true)
        
    }

    @IBAction func btnBack(){
    
        
        let component = objappDelegate.strPath.split(separator: "/")
        let strpathdirectory = objdirecotry.pathDirectory.split(separator: "/")
        
        if(component.last == strpathdirectory.last){
            self.title = "FileManager"
            objappDelegate.strPath = ""
            viewDidLoad()
        }else{
            let head = component.dropLast(1).joined(separator: "/")
            objappDelegate.strPath = head
            viewDidLoad()
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func btnAddImage(){
        /*let objimageview:ImageViewController = (self.storyboard?.instantiateViewController(withIdentifier: "ImageViewController") as? ImageViewController)!
        
        self.present(objimageview, animated: true, completion: nil)*/
        
       /* let objGallary:GallaryViewController = (storyboard?.instantiateViewController(withIdentifier: "GallaryViewController") as? GallaryViewController)!
        navigationController?.pushViewController(objGallary, animated: true)*/
       // self.present(objGallary, animated: true, completion: nil)
        
        let objcollection:CollectionViewController = (storyboard?.instantiateViewController(withIdentifier: "CollectionViewController") as? CollectionViewController)!
        
        navigationController?.pushViewController(objcollection, animated: true)
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.cellForRow(at: indexPath)?.setSelected(false, animated: true)
        
       
        var selectname:String!
        let objpass:passwordViewController = passwordViewController()
        
        selectDirectory = "\(objappDelegate.arrFileManager[indexPath.row])"
        if (objappDelegate.strPath.isEmpty){
            selectedPath = path.appending("/\(selectDirectory)")
        }else{
            selectedPath = objappDelegate.strPath.appending("/\(selectDirectory)")
        }
        self.title = selectDirectory
        objappDelegate.selectTitle = selectDirectory
        objappDelegate.strPath = selectedPath
        
        objpass.fetchDataInDatabuse()
        if objpass.arrpass.isEmpty{
            print("erroe arr empty")
            
        } else {
            
            for i in objpass.arrpass{
                let name = i["directoryname"] as? String
                selectname = name
                if selectDirectory == selectname {
                    
                    let objpassword:passwordViewController = (storyboard?.instantiateViewController(withIdentifier: "passwordViewController") as? passwordViewController)!
                    
                    objpassword.nameDirectory = selectDirectory

                    self.present(objpassword, animated: true, completion: nil)
                }
            }
       
        }
        let objfilemanager:FileManagerViewController = self.storyboard?.instantiateViewController(withIdentifier: "FileManagerViewController") as! FileManagerViewController
        
        navigationController?.pushViewController(objfilemanager, animated: true)
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
