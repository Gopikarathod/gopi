//
//  ViewController.swift
//  Filemanager
//
//  Created by agile-10 on 31/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{
    
    
   
    @IBOutlet var tblview:UITableView!
    
    let Dog:[String] = ["1.jpg","2.jpg","3.png","4.jpg","5.jpg","6.jpg","7.jpeg","8.jpg","9.jpg","10.jpg"]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tblview.dataSource = self
        tblview.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Dog.count
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = (tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as? TableViewCell)!
        let objimg:String = Dog[indexPath.row]
            cell.img.image = UIImage.init(named: "\(objimg)")
            //cell.lbl.text = name[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 160
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

