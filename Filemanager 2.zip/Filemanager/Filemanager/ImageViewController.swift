//
//  ImageViewController.swift
//  Filemanager
//
//  Created by agile-10 on 31/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ImageViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet var tblImageview:UITableView!
    var arrImg:[[String:Any]] = []
    var temparr:[[String:Any]] = []
    let uncheckImage = UIImage.init(named: "uncheck.jpg")
    let checkImage = UIImage.init(named: "check.png")
    let objapp = UIApplication.shared.delegate as! AppDelegate
    let objdict:DirectoryViewController = DirectoryViewController()
    var dicPath:String!
    var filePath:String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblImageview.delegate = self
        self.tblImageview.dataSource = self
        
        imageDictionary(withNameImage: "9.jpg", withIsSelected: false)
        imageDictionary(withNameImage: "10.jpg", withIsSelected: false)
        imageDictionary(withNameImage: "16.jpg", withIsSelected: false)
        imageDictionary(withNameImage: "19.jpg", withIsSelected: false)
        
        dicPath = objdict.pathDirectory
       // print(arrImg)
        // Do any additional setup after loading the view.
    }
    
    func imageDictionary(withNameImage image:String,withIsSelected selected:Bool){
        let dict:[String:Any] = ["name":image,"isSelected":selected]
        arrImg.append(dict)
    }
    
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrImg.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:ImageviewCell = (tableView.dequeueReusableCell(withIdentifier: "ImageviewCell") as? ImageviewCell)!
        var objarr = arrImg[indexPath.row]
        let imageName:String = (objarr["name"] as? String)!
        let  isSelected:Bool = (objarr["isSelected"] as? Bool)!

        
        cell.imageView?.image = UIImage.init(named: "\(imageName)")
        
        if (isSelected == false){
            cell.btnRadioButton.setImage(uncheckImage, for: UIControlState.normal)
        } else{
            cell.btnRadioButton.setImage(checkImage, for: UIControlState.normal)
        }
               return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var objselect = arrImg[indexPath.row]
        var obj:Bool = objselect["isSelected"] as! Bool
        if obj == false{
            obj = true
        }else{
            obj = false
        }
        objselect.updateValue(obj, forKey: "isSelected")
        arrImg[indexPath.row] = objselect
       // print(objselect)
        tblImageview.reloadData()

}
    
    
    @IBAction func btnCancle(){
        self.dismiss(animated: true, completion: nil)
    }
    
    func saveImage(){
        
        for i in temparr{
        let objImg:String = i["name"] as! String
        print(objImg)
            let aryName:[String] = objImg.components(separatedBy: ".");
            
            guard let strFileName = aryName.first else {
                return
            }
            guard let strFileExtenstion = aryName.last else {
                return
            }
            
            if let bundlePAth:String  = Bundle.main.path(forResource: strFileName , ofType: strFileExtenstion)
            {
                if (objapp.strPath.isEmpty){
                    filePath = dicPath.appending("/\(strFileName).\(strFileExtenstion)")

                }else {
                 filePath = (objapp.strPath).appending("/\(strFileName).\(strFileExtenstion)")
                }
            
                do{
                    
                    if !FileManager.default.fileExists(atPath: filePath){
                        try FileManager.default.copyItem(atPath: bundlePAth , toPath: filePath)
                    }
            
                    if (objapp.strPath.isEmpty){
                        let _:[String] = try FileManager.default.contentsOfDirectory(atPath:dicPath)

                    }else{
                        let _:[String] = try FileManager.default.contentsOfDirectory(atPath:objapp.strPath)
                    }
                    
                }
                catch {
                    print(error.localizedDescription)
                }
                
            }
            
           /* let bundlePAth:String  = Bundle.main.path(forResource: "uncheck" , ofType: "jpg")!
            let filePath:String = (objapp.strPath).appending("/123456.jpg")*/
            
        }
        
    }
      
    @IBAction func btnSave(){
        
        
        for i in arrImg{
                let objselect:Bool = i["isSelected"] as! Bool
                if objselect == true{
                temparr.append(i)
                print(temparr)
        }else{
                    if temparr.isEmpty{
                            let alertvc:UIAlertController = UIAlertController.init(title: "Error", message: "No Selected Any Image", preferredStyle:UIAlertControllerStyle.alert)
                            if (temparr.isEmpty){
                                    let selectImg:UIAlertAction = UIAlertAction.init(title: "Select Image", style: UIAlertActionStyle.default) { (action) in
                                        print("Select Img")
                                }
                                alertvc.addAction(selectImg)
                                self.present(alertvc, animated: true, completion: nil)
                            }

                        }
                    }
                    saveImage()
            }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
