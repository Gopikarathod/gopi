//
//  GallaryViewController.swift
//  Filemanager
//
//  Created by agile-10 on 21/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class GallaryViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    let imgController = UIImagePickerController()
    let objappdelegate = UIApplication.shared.delegate as? AppDelegate
    let objdirecotry:DirectoryViewController = DirectoryViewController()
    var strFilePath = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imgController.delegate = self
        imgController.sourceType = .photoLibrary
        self.present(imgController, animated: true, completion: nil)

        // Do any additional setup after loading the view.
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
      //  <UIImage: 0x6040000b9380> size {200, 150} orientation 0 scale 1.000000
        let selectedImage:UIImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        print(selectedImage)
    
        let objData:Data = UIImagePNGRepresentation(selectedImage)!
        
        if (objappdelegate?.strPath.isEmpty)!{
            strFilePath = (objdirecotry.pathDirectory.appending("/\(objData)"))
        }else{
            strFilePath = (objappdelegate?.strPath.appending("/\(objData)"))!
        }
        
        do{
           try objData.write(to: URL.init(fileURLWithPath: strFilePath))
        }catch{
            print(error.localizedDescription)
        }
        
        self.dismiss(animated: true, completion: nil)
       navigationController?.popViewController(animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
