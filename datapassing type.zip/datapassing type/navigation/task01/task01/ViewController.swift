//
//  ViewController.swift
//  task01
//
//  Created by agile-10 on 24/08/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{

    @IBOutlet var tblinfo:UITableView!
    var updatedata:String = ""
    
    var data:[[String:String]] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let objbarbtn:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonSystemItem.add, target: self, action: #selector(ViewController.submit))
        self.navigationItem.rightBarButtonItem = objbarbtn
        
       
       
        self.tblinfo.dataSource = self
      self.tblinfo.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
               self.tblinfo.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    @IBAction func submit() {
        updatedata = "false"
        
        if let objemp:empdataViewController = storyboard?.instantiateViewController(withIdentifier: "empdataViewController") as? empdataViewController {
            objemp.update = updatedata
            objemp.emparr = data
            self.navigationController?.pushViewController(objemp, animated: true)
            
          
            
        }
   
    }
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
let call:dataTableViewCell = tableView.dequeueReusableCell(withIdentifier: "dataTableViewCell") as! dataTableViewCell
        call.accessoryType = UITableViewCellAccessoryType.disclosureIndicator
      var obj:[String:String] = self.data[indexPath.row]
    
        call.fnm.text = obj["Fname"]
        call.Lnm.text = obj["Lname"]
        call.Desig.text = obj["Designation"]
        return call
    
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        updatedata = "true"
       
        let emp:empdataViewController = storyboard?.instantiateViewController(withIdentifier: "empdataViewController") as! empdataViewController
        
            var info:[String:String] = data[indexPath.row]
            emp.detail["id"] = info["id"]!
            emp.detail["Fname"] = info["Fname"]!
            emp.detail["Lname"] = info["Lname"]!
            emp.detail["City"] = info["City"]!
            emp.detail["State"] = info["State"]!
            emp.detail["Country"] = info["Country"]!
            emp.detail["Bloodgroup"] = info["Bloodgroup"]!
            emp.detail["Mobilenum"] = info["Mobilenum"]!
            emp.detail["Homenum"] = info["Homenum"]!
            emp.detail["Designation"] = info["Designation"]!
            emp.detail["About"] = info["About"]!
            emp.emparr = data
            emp.update = updatedata
            self.navigationController?.pushViewController(emp, animated: true)
       
    }
}

