//
//  sharedinstances.swift
//  task01
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class sharedinstances: NSObject {
    var arremp:[[String:String]] = []
    static let shared:sharedinstances = sharedinstances()
    override init() {
        arremp = []
       
    }

}
