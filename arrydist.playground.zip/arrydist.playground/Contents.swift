//: Playground - noun: a place where people can play

import UIKit

    

var arystud = ["gopi","radhi","dipee"]

for name in arystud {
    print(name, separator: "", terminator: "\n")
}
var disstud:[Int:String] = [1:"one",2:"two",3:"three"]

var somevar = disstud[1]
print(somevar, separator: "", terminator: "\n")
print(disstud[2])


    



