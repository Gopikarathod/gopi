//
//  fourViewController.swift
//  viewcontorllercoding
//
//  Created by agile-02 on 31/07/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

var fourlable:UILabel!
var firbutton:UIButton!
var secbutton:UIButton!
var thirbutton:UIButton!

class fourViewController: UIViewController {
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fourlable = UILabel.init(frame: CGRect.init(x: 60, y: 60, width: 50, height: 50))
        fourlable.text = "four"
        fourlable.textColor = UIColor.white
        fourlable.backgroundColor = UIColor.gray
        self.view.addSubview(fourlable)
        
        firbutton = UIButton.init(frame: CGRect.init(x: 60, y: 180, width: 100, height: 50))
        firbutton.addTarget(self, action: #selector(buttonfir), for: UIControlEvents.touchUpInside)
        firbutton.setTitle("viewfirst", for: UIControlState.normal)
        firbutton.backgroundColor = UIColor.gray
        self.view.addSubview(firbutton)
        
        secbutton = UIButton.init(frame: CGRect.init(x: 60, y: 250, width: 100, height: 50))
        secbutton.addTarget(self, action: #selector(buttonsec), for: UIControlEvents.touchUpInside)
        secbutton.setTitle("viewsecond", for: UIControlState.normal)
        secbutton.backgroundColor = UIColor.gray
        self.view.addSubview(secbutton)
        
        thirbutton = UIButton.init(frame: CGRect.init(x: 60, y: 320, width: 100, height: 50))
        thirbutton.addTarget(self, action: #selector(buttonthired), for: UIControlEvents.touchUpInside)
        thirbutton.setTitle("viewthired", for: UIControlState.normal)
        thirbutton.backgroundColor = UIColor.gray
        self.view.addSubview(thirbutton)
        
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func buttonfir(){
        self.navigationController?.popToRootViewController(animated: true)
        
    }
    @IBAction func buttonsec(){
        
       let viewcont = navigationController?.viewControllers
        for values in viewcont! {
            if values is secondViewController
            {
                
                navigationController?.popToViewController(values, animated: true)
            }
        }
        
    }

    
    @IBAction func buttonthired(){
      self.navigationController?.popViewController(animated: true)
    }

}
