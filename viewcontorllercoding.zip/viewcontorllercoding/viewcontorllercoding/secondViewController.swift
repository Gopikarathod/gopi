//
//  secondViewController.swift
//  viewcontorllercoding
//
//  Created by agile-02 on 31/07/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
var secondlable:UILabel!
var secondbutton:UIButton!

class secondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        secondlable = UILabel.init(frame: CGRect.init(x: 30, y: 40, width: 100, height: 50))
        secondlable.text = "second"
        secondlable.textColor = UIColor.white
        secondlable.backgroundColor = UIColor.blue
        self.view.addSubview(secondlable)
        
        secondbutton = UIButton.init(frame: CGRect.init(x: 30, y: 150, width: 100, height: 50))
        secondbutton.addTarget(self, action: #selector(buttonsecond), for: UIControlEvents.touchUpInside)
        secondbutton.setTitle("viewthired", for: UIControlState.normal)

        secondbutton.backgroundColor = UIColor.blue
        self.view.addSubview(secondbutton)
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func buttonsecond(){
        let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        
        if let thiredviewcontroller:thiredViewController = storyBoard.instantiateViewController(withIdentifier: "thiredViewController") as? thiredViewController {
            
            self.navigationController?.pushViewController(thiredviewcontroller, animated: true)
        }
        
    }

}
