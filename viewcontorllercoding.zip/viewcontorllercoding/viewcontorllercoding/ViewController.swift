//
//  ViewController.swift
//  viewcontorllercoding
//
//  Created by agile-02 on 31/07/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var lablefirst:UILabel!
    var buttonfirst:UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        lablefirst = UILabel.init(frame: CGRect.init(x: 40, y: 50, width: 100, height: 50))
        lablefirst.text = "First"
        lablefirst.backgroundColor = UIColor.red
        lablefirst.textColor = UIColor.white
        self.view.addSubview(lablefirst)
        
        buttonfirst = UIButton.init(frame: CGRect.init(x: 40, y: 150, width: 110, height: 30))
        buttonfirst.setTitle("viewSecond", for: UIControlState.normal)
        buttonfirst.backgroundColor = UIColor.red
        buttonfirst.addTarget(self, action: #selector(firstbutton), for: UIControlEvents.touchUpInside)
        self.view.addSubview(buttonfirst)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func firstbutton() {
        
       
        
        if let secondviewcontroll:secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "secondViewController") as? secondViewController {
            
                self.navigationController?.pushViewController(secondviewcontroll, animated: true)
        }
    }


}

