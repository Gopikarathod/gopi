//
//  thiredViewController.swift
//  viewcontorllercoding
//
//  Created by agile-02 on 31/07/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

var thiredlable:UILabel!
var thiredbutton:UIButton!

class thiredViewController: UIViewController {
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        thiredlable = UILabel.init(frame: CGRect.init(x: 30, y: 40, width: 100, height: 50))
        thiredlable.text = "thired"
        thiredlable.textColor = UIColor.white
        thiredlable.backgroundColor = UIColor.purple
        self.view.addSubview(thiredlable)
        
        thiredbutton = UIButton.init(frame: CGRect.init(x: 30, y: 150, width: 100, height: 50))
        thiredbutton.addTarget(self, action: #selector(buttonthired), for: UIControlEvents.touchUpInside)
        thiredbutton.setTitle("viewfour", for: UIControlState.normal)
        thiredbutton.backgroundColor = UIColor.purple
        self.view.addSubview(thiredbutton)
       

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func buttonthired(){
        
        var storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        
        if let fourviewcontroller:fourViewController = storyBoard.instantiateViewController(withIdentifier: "fourViewController") as? fourViewController {
            
            self.navigationController?.pushViewController(fourviewcontroller, animated: true)
        }
    }

}
