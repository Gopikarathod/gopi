//
//  ViewController.swift
//  prectical
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    

   @IBOutlet var tblview:UITableView!
    var arrinfo:[[String:String]] = []
    var update = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
   
        // Do any additional setup after loading the view, typically from a nib.

    
        print(arrinfo)
        self.tblview.dataSource = self
        self.tblview.delegate = self
        print(arrinfo)
        print(self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let objapp = UIApplication.shared.delegate as! AppDelegate
        self.arrinfo = objapp.arrdata
        tblview.reloadData()
    }
    
    @IBAction func btnadd(){
        
        update = "false"
        let ObjSecondviewController:SecondViewController = (storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController)!
        ObjSecondviewController.update = update
        self.navigationController?.pushViewController(ObjSecondviewController, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(arrinfo)
        return arrinfo.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:ViewTableCell=tableView.dequeueReusableCell(withIdentifier: "ViewTableCell") as! ViewTableCell
        let objarr:[String:String] = self.arrinfo[indexPath.row]
        
        cell.lblid.text = objarr["id"]
        cell.lblname.text = objarr["name"]
        cell.lblcity.text = objarr["city"]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        update = "true"
        let objinfo:[String:String] = self.arrinfo[indexPath.row]
        let second:SecondViewController = storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        
        second.Dicdetail["id"]=objinfo["id"]
        second.Dicdetail["name"]=objinfo["name"]
        second.Dicdetail["city"]=objinfo["city"]
        second.update = update
        
        self.navigationController?.pushViewController(second, animated: true)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

