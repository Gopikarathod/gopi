//
//  SecondViewController.swift
//  prectical
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController,UITextFieldDelegate{
    
    @IBOutlet var txtid:UITextField!
    @IBOutlet var txtname:UITextField!
    @IBOutlet var txtcity:UITextField!
    var btnsubmit:UIButton!
    var Dicdetail:[String:String] = [:]
    var update = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Registration"
        self.txtid.delegate = self
        self.txtname.delegate = self
        self.txtcity.delegate = self
        //txtid.isEnabled = false
        print(self)
        print(Dicdetail)
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.txtid.text = Dicdetail["id"]
        self.txtname.text = Dicdetail["name"]
        self.txtcity.text = Dicdetail["city"]
        
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        Dicdetail["id"] = txtid.text
        Dicdetail["name"] = txtname.text
        Dicdetail["city"] = txtcity.text
        
        return true
    }
    
    @IBAction func BtnSubmit(){
        self.view.endEditing(true)
        let objapp = UIApplication.shared.delegate as! AppDelegate
        
        if (update == "false"){
            objapp.arrdata.append(Dicdetail)
            print(objapp.arrdata)
            
        } else {
            objapp.arrdata.remove(at: Int(Dicdetail["id"]!)! - 1)
            objapp.arrdata.insert(Dicdetail, at: (Int(Dicdetail["id"]!)! - 1))
        }
        
        UserDefaults.standard.set(objapp.arrdata, forKey: "update")
        UserDefaults.standard.synchronize()
        self.navigationController?.popViewController(animated: true)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
