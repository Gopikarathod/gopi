//
//  ViewController.swift
//  student_dist
//
//  Created by agile-02 on 19/07/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var studinfo:[[String:Any]]=[]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.stud(withname: "gopi", withaddress: "botad", withnumber:8962355544, withmarks:65,withstudid: 1)
        self.stud(withname: "radhi", withaddress: "ahmedabad", withnumber:6325874199, withmarks:80,withstudid: 2)
        self.stud(withname: "dipee", withaddress: "bhavnager", withnumber:7896541239, withmarks:60,withstudid: 3)
        
            studdispaly()
            print("\n")
            studupdate(withname:"radhi")
            studdispaly()
            print("\n")
            studdelete(withname:"dipee")
            studdispaly()
      
       
        // Do any additional setup after loading the view, typically from a nib.
    }

    /// <#Description#>
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    
    
    func stud(withname name:String,withaddress address:String,withnumber number:Int,withmarks marks:Int,withstudid studid:Int){
      
        let studdata:[String:Any]=["name":name,"address":address,"number":number,"marks":marks,"studid":studid]
    
        studinfo.append(studdata)
        
        
        
    }
    func studdelete(withname name:String){
       
        var i=0
        for _ in studinfo {
            
            var studdict = studinfo[i]
            if name == studdict["name"] as? String {
                studinfo.remove(at: i)
                break
                }
            i = i + 1
            
            }

        }
    
    func studupdate(withname name:String){
        
        var i=0
        for _ in studinfo {
            
            var studdict = studinfo[i]
            if name == studdict["name"] as? String {
                studdict.updateValue("nilu", forKey:"name")
                studinfo[i] = studdict
                break
            }
            i = i + 1
            
        }
    
    }
    

        
    func studdispaly(){
        print(studinfo)
       
        
    }
    
  
      
}



