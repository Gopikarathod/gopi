//
//  ViewController.swift
//  drawlbl
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 AshishSalet. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate{

    @IBOutlet var cnt:UITextField!
    @IBOutlet var widt:UITextField!
    @IBOutlet var heigh:UITextField!
    @IBOutlet var lbl:UILabel!
    @IBOutlet var viw:UIView!
    @IBOutlet var scroll:UIScrollView!
    var Draw:UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        cnt = UITextField.init(frame: CGRect.init(x: 100, y: 50, width: 150, height: 40))
        cnt.placeholder = "count"
        cnt.keyboardType = .numberPad
        cnt.becomeFirstResponder()
        cnt.delegate = self
        self.view.addSubview(cnt)
        
        widt = UITextField.init(frame: CGRect.init(x: 170, y:50, width: 150, height: 40))
        widt.placeholder = "width"
        widt.keyboardType = .numberPad
        widt.delegate = self
        self.view.addSubview(widt)
        
        heigh = UITextField.init(frame: CGRect.init(x: 240, y:50, width: 150, height: 40))
        heigh.placeholder = "height"
        heigh.keyboardType = .numberPad
        heigh.delegate = self
        self.view.addSubview(heigh)
        
        Draw = UIButton.init(frame: CGRect.init(x: 80, y: 100, width: 250, height: 30))
        Draw.addTarget(self, action: #selector(btndraw), for: .touchUpInside)
        Draw.setTitle("Draw", for: .normal)
        Draw.backgroundColor = UIColor.blue
        self.view.addSubview(Draw)
        Draw.isEnabled = false
        
        
      
        
        
        scroll = UIScrollView.init(frame: CGRect.init(x: 10, y: 150, width: self.view.frame.width - 20,height:self.view.frame.height - 160))
        scroll.backgroundColor = UIColor.darkGray
        scroll.isScrollEnabled=true
       self.view.addSubview(scroll)
        
          viw = UIView.init(frame: CGRect.init(x: 0, y: 0, width: self.scroll.frame.width,height:self.scroll.frame.height))
        scroll.addSubview(viw)
        
   
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if (cnt.text?.count == 0 && widt.text?.count == 0 && heigh.text?.count == 0)
        {
            Draw.isEnabled = false
        }
        else
        {
            Draw.isEnabled = true
        }
        return true
    }
   
    
    
    @IBAction func btndraw() {
        
       
       
        
        for view in viw.subviews
        {
            view.removeFromSuperview()
        }
        var w : CGFloat = 0
        var h : CGFloat = 10
        var space : CGFloat = 0
        for i in 1...Int(cnt.text!)! {
            print(self.viw.frame.height)
           
            if(CGFloat(Int(widt.text!)!) + w > self.viw.frame.width)
            {
                h = h + CGFloat(Int(heigh.text!)!) + 5
                w = 0
                space = 0
            }
            if(w == 0)
            {
            let widthlbl = CGFloat(Int(widt.text!)!)
            let viwsize = self.viw.frame.width
            let modual = viwsize .truncatingRemainder(dividingBy: widthlbl)
            let rimender = (viwsize / widthlbl)
            space = (modual / CGFloat(Int(rimender+1)))
                w = space
            }
          /*  if ((CGFloat(Int(heigh.text!)!)) + h > self.viw.frame.height)
            {
                print("out of size")
                break
            }
            else
            {*/
            lbl = UILabel.init(frame: CGRect.init(x:w, y: 5 + h, width:CGFloat(Int(widt.text!)!), height:CGFloat(Int(heigh.text!)!)))
            lbl.backgroundColor = UIColor.white
            lbl.text = "\(i)"
            viw.addSubview(lbl)
            w = w + CGFloat(Int(widt.text!)!) + space
            scroll.contentSize = CGSize.init(width:self.viw.frame.width, height:h + CGFloat(Int(heigh.text!)!) + 10)
            
          //  }
        }
      
        
    }


}



