//
//  TableViewCell.swift
//  printdataintableview
//
//  Created by agile-10 on 28/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    
   @IBOutlet var lbl:UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
