//
//  ViewController.swift
//  printdataintableview
//
//  Created by agile-10 on 28/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate{

    @IBOutlet var tblview:UITableView!
    @IBOutlet var serchbar:UISearchBar!
    var i = 0

    var arrdata:[String]=["gopi","radhi","rachna","kavita"]
    var data:[String]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tblview.dataSource = self
        self.tblview.delegate = self
        self.serchbar.delegate = self
        data=arrdata
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(arrdata)
        return 50
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    //    let cell:TableViewCell=tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        
        
        let cell:UITableViewCell = UITableViewCell.init(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = data[i]
            if i == 3
            {
                i = 0
            }
            else{
                i = i + 1
            }
        return cell
        
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        data = searchText.isEmpty ? arrdata : arrdata.filter({(dataString: String) -> Bool in
            return dataString.range(of: searchText, options: .caseInsensitive) != nil
        })
        tblview.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

