//
//  empTableViewCell.swift
//  model
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class empTableViewCell: UITableViewCell {
    
    @IBOutlet var lblmain:UILabel!
    @IBOutlet var txtmain:UITextField!
    @IBOutlet var btnmain:UIButton!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
