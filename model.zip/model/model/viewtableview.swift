//
//  viewtableview.swift
//  model
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class viewtableview: UITableView,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate{
    let objemp:employee = employee()
    let calarray:empViewController = empViewController()
    var arrview:[[String:String]] = []
    
    func data(){
        self.delegate = self
        self.dataSource = self
       /* self.blockFunction { (Any) in
            arrview = value as! [String:String]
        }*/
        //self.tblemp.didSetContactSelectionHandler { (empdata) in
            //  print(contact.strFirstName)
           // print(empdata)
      //  arrview = objemp.arremp
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrview.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:viewTableViewCell = self.dequeueReusableCell(withIdentifier: "viewTableViewCell") as! viewTableViewCell
        
        var objview:[String:String] = arrview[indexPath.row]
        
        cell.fname.text = objview["Fname"]
        cell.lname.text = objview["Lname"]
        cell.desi.text = objview["Designation"]
        
        return cell
                  /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

        }
    
  /*  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let emp:emptableview = tableView.dequeueReusableCell(withIdentifier: "emptableview") as! emptableview
        
        var info:[String:String] = objemp.arremp[indexPath.row]
        
        emp.detail["id"] = info["id"]!
        emp.detail["Fname"] = info["Fname"]!
        emp.detail["Lname"] = info["Lname"]!
        emp.detail["City"] = info["City"]!
        emp.detail["State"] = info["State"]!
        emp.detail["Country"] = info["Country"]!
        emp.detail["Bloodgroup"] = info["Bloodgroup"]!
        emp.detail["Mobilenum"] = info["Mobilenum"]!
        emp.detail["Homenum"] = info["Homenum"]!
        emp.detail["Designation"] = info["Designation"]!
        emp.detail["About"] = info["About"]!
       // objemp.update = "true"
        
     //   self.navigationController?.pushViewController(emp, animated: true)
        
    }*/
}
