//
//  viewTableViewCell.swift
//  model
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class viewTableViewCell: UITableViewCell {
    
    @IBOutlet var fname:UILabel!
    @IBOutlet var lname:UILabel!
    @IBOutlet var desi:UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
