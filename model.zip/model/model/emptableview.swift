//
//  emptableview.swift
//  model
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class emptableview: UITableView,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate{
    private var didSelectContact:((employee) -> Void )?
    var detail:[String:String] = [:]
    var update:String = ""
    var objemp:employee = employee()
    var arrayemp:[[String:String]] = []
    
    func data(){
        self.delegate = self
        self.dataSource = self
    }
    
    func didSetContactSelectionHandler(withHandler handler:@escaping ((employee) -> Void )){
        self.didSelectContact = handler
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 12
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print(update)
        if (update == "false"){
            if(indexPath.row < 11)
            {
                if let cell:empTableViewCell = self.dequeueReusableCell(withIdentifier:     "empTableViewCell") as? empTableViewCell
                {
                    cell.txtmain.delegate = self
                    cell.txtmain.tag = indexPath.row
                    if(indexPath.row == 0)
                    {
                        cell.lblmain.text = "Id"
                        cell.txtmain.isEnabled = false
                        detail["id"] = "\(objemp.arremp.count+1)"
                        cell.txtmain.text = detail["id"]
                        print(detail["id"] ?? "")
                    
                    }
                    else if(indexPath.row == 1)
                    {
                        cell.lblmain.text = "First Name"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Fname"]
                        cell.txtmain.becomeFirstResponder()
                    
                    }
                    else if(indexPath.row == 2)
                    {
                        cell.lblmain.text = "Last Name"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Lname"]
                    
                    
                    }
                    else if(indexPath.row == 3)
                    {
                        cell.lblmain.text = "City"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["City"]
                    }
                    else if(indexPath.row == 4)
                    {
                        cell.lblmain.text = "State"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["State"]
                    }
                    else if(indexPath.row == 5)
                    {
                        cell.lblmain.text = "Country"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Country"]
                    }
                    else if(indexPath.row == 6)
                    {
                        cell.lblmain.text = "Blood Group"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Bloodgroup"]
                    }
                    else if(indexPath.row == 7)
                    {
                        cell.lblmain.text = "Mobile Num"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Mobilenum"]
                    }
                    else if(indexPath.row == 8)
                    {
                        cell.lblmain.text = "Home Num"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Homenum"]
                    }
                    else if(indexPath.row == 9)
                    {
                        cell.lblmain.text = "Designation"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Designation"]
                    }
                    else if(indexPath.row == 10)
                    {
                        cell.lblmain.text = "About"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["About"]
                    }
                
                    return cell
                }
            }
            else
            {
                if let cell:empTableViewCell=tableView.dequeueReusableCell(withIdentifier: "empTableViewCell1") as? empTableViewCell
                {
                    cell.btnmain.setTitle("Add", for: .normal)
                    cell.btnmain.addTarget(self, action: #selector(submit), for: UIControlEvents.touchUpInside)
                    cell.btnmain.backgroundColor = UIColor.black
                    cell.btnmain.setTitleColor(.white, for: .normal)
                    return cell
                }
            
            }
        }
        else{
            if(indexPath.row < 11)
            {
                if let cell:empTableViewCell=tableView.dequeueReusableCell(withIdentifier: "empTableViewCell") as? empTableViewCell
                {
                    cell.txtmain.delegate = self
                    cell.txtmain.tag = indexPath.row
                    if(indexPath.row == 0)
                    {
                        cell.lblmain.text = "Id"
                        cell.txtmain.isEnabled = false
                        cell.txtmain.text = detail["id"]
                        
                    }
                    else if(indexPath.row == 1)
                    {
                        cell.lblmain.text = "First Name"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Fname"]
                        cell.txtmain.becomeFirstResponder()
                        
                    }
                    else if(indexPath.row == 2)
                    {
                        cell.lblmain.text = "Last Name"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Lname"]
                        
                        
                    }
                    else if(indexPath.row == 3)
                    {
                        cell.lblmain.text = "City"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["City"]
                    }
                    else if(indexPath.row == 4)
                    {
                        cell.lblmain.text = "State"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["State"]
                    }
                    else if(indexPath.row == 5)
                    {
                        cell.lblmain.text = "Country"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Country"]
                    }
                    else if(indexPath.row == 6)
                    {
                        cell.lblmain.text = "Blood Group"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Bloodgroup"]
                    }
                    else if(indexPath.row == 7)
                    {
                        cell.lblmain.text = "Mobile Num"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Mobilenum"]
                    }
                    else if(indexPath.row == 8)
                    {
                        cell.lblmain.text = "Home Num"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Homenum"]
                    }
                    else if(indexPath.row == 9)
                    {
                        cell.lblmain.text = "Designation"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["Designation"]
                    }
                    else if(indexPath.row == 10)
                    {
                        cell.lblmain.text = "About"
                        cell.txtmain.isEnabled = true
                        cell.txtmain.text = detail["About"]
                    }
                    
                    return cell
                }
            }
            else
            {
                if let cell:empTableViewCell=tableView.dequeueReusableCell(withIdentifier: "empTableViewCell1") as? empTableViewCell
                {
                    cell.btnmain.setTitle("update", for: .normal)
                    cell.btnmain.addTarget(self, action: #selector(submit), for: UIControlEvents.touchUpInside)
                    cell.btnmain.backgroundColor = UIColor.black
                    cell.btnmain.setTitleColor(.white, for: .normal)
                    return cell
                }
                
            }
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return  textField.resignFirstResponder()
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        /* if (textField.tag == 0){
         return becomeFirstResponder()
         }*/
        if textField.tag == 0 {
            detail["id"] = textField.text!
        }
        else if textField.tag == 1 {
            detail["Fname"] = textField.text!
        }
        else if textField.tag == 2 {
            detail["Lname"] = textField.text!
        }
        else if textField.tag == 3 {
            detail["City"]  = textField.text!
        }
        else if textField.tag == 4 {
            detail["State"] = textField.text!
        }
        else if textField.tag == 5 {
            detail["Country"] = textField.text!
        }
        else if textField.tag == 6 {
            detail["Bloodgroup"] = textField.text!
        }
        else if textField.tag == 7 {
            detail["Mobilenum"] = textField.text!
        }
        else if textField.tag == 8 {
            detail["Homenum"] = textField.text!
        }
        else if textField.tag == 9{
            detail["Designation"] = textField.text!
        }
        else if textField.tag == 10 {
            detail["About"] = textField.text!
        }
        
        return true
    }
    
    
    
    @objc func submit(){
        
       
        
        if let value = self.didSelectContact {
            self.endEditing(true)
            if(update == "false")
            {
            objemp.arremp.append(detail)
            }
            else
            {
                
            }
            //let objContact:employee = arrayemp
            value(objemp)
        }
        
    }
    
    

    
    

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
