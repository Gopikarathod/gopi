//
//  ViewController.swift
//  model
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tblview:viewtableview!
    let objemp:employee = employee()
    var update:String = ""
    var datacall:((Any) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.tblview.data()
    }
    @IBAction func submit(){
        update = "false"
        let objempview:empViewController = storyboard?.instantiateViewController(withIdentifier: "empViewController")as! empViewController
            objempview.empupdate = update
        print(objempview.empupdate)
        self.navigationController?.pushViewController(objempview, animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

