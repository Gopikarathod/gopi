//
//  empViewController.swift
//  model
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class empViewController: UIViewController {
    let objemp:employee = employee()
    var blockFunction:((Any)->Void)?
  //  @IBOutlet weak var tblContact:ContactTableView!
    @IBOutlet weak var tblemp:emptableview!
    var empupdate:String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(empupdate)
        self.tblemp.data()
        self.tblemp.update = empupdate
        
        self.tblemp.didSetContactSelectionHandler { (empdata) in
          //  print(contact.strFirstName)
            print(empdata)
            if let value = self.blockFunction {
            self.blockFunction = { (value) in
              //  print(value)
                value(empdata)
            }
        self.navigationController?.popViewController(animated: true)
        }
        // Do any additional setup after loading the view
     }
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
