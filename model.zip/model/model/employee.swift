//
//  employee.swift
//  model
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class employee: NSObject {
    
    var arremp:[[String:String]] = []
 //   var update:String!
    
    override init() {
      //  print(update)
        arremp = []
    }

}
