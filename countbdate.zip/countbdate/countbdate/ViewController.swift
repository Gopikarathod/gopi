////
//  ViewController.swift
//  datepickerview
//
//  Created by agile-10 on 14/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit


class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate{
    
    
   
    var datepickerview:UIDatePicker! = UIDatePicker()
    var pickerview:UIPickerView! = UIPickerView()
    @IBOutlet var myview:UIView!
    @IBOutlet var txtbdate:UITextField!
    @IBOutlet var txtcountry:UITextField!
    @IBOutlet var txtstate:UITextField!
    @IBOutlet var txtcity:UITextField!
    @IBOutlet var lbldiff:UILabel!
    var currentdate = Date()

    
     var arrcountry:[[String:String]] = []
     var arrstate:[[String:String]] = []
     var arrcity:[[String:String]] = []

    var arrtempcountry:[[String:String]] = []
    var arrtempstate:[[String:String]] = []
    var arrtempcity:[[String:String]] = []

    let dateformatter:DateFormatter = DateFormatter()
  
  
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.datepickerview.isHidden = true
        self.pickerview.isHidden = true
        self.pickerview.dataSource = self
        self.pickerview.delegate = self
        self.txtbdate.delegate = self
        self.txtcountry.delegate = self
        self.txtstate.delegate = self
        self.txtcity.delegate = self
        
        txtbdate.becomeFirstResponder()
        datepickerview.datePickerMode = .date
        datepickerview.addTarget(self, action: #selector(pickerView(_:didSelectRow:inComponent:)), for: .valueChanged)
        txtbdate.inputView = datepickerview
        txtcountry.inputView = pickerview
        txtstate.inputView = pickerview
        txtcity.inputView = pickerview
        country(withcountryid: "0", withcountry: "Select")
        country(withcountryid: "1", withcountry: "India")
        country(withcountryid: "2", withcountry: "US")
        state(withcountryid: "0", withstateid: "0", withstate: "Select")
        state(withcountryid: "1", withstateid: "1", withstate: "gujrat")
        state(withcountryid: "1", withstateid: "2", withstate: "MP")
        state(withcountryid: "2", withstateid: "3", withstate: "floreda")
        state(withcountryid: "2", withstateid: "4", withstate: "new jersey")
        city(withcountryid: "0", withstateid: "0", withcityid: "0", withcity: "Select")
        city(withcountryid: "1", withstateid: "1", withcityid: "1", withcity: "ahemdabad")
        city(withcountryid: "1", withstateid: "1", withcityid: "2", withcity: "bhavnagar")
        city(withcountryid: "1", withstateid: "2", withcityid: "3", withcity: "bhopal")
        city(withcountryid: "2", withstateid: "3", withcityid: "4", withcity: "maimi")
        city(withcountryid: "2", withstateid: "3", withcityid: "5", withcity: "tampa")
        
        arrtempcountry = arrcountry
        txtcountry.text = "\(arrcountry[0])"
        txtstate.text = "\(arrstate[0])"
        txtcity.text = "\(arrcity[0])"
        }
    
    func country(withcountryid countryid:String,withcountry country:String){
        let dictionarycountry:[String:String] = ["countryid":countryid,"country":country]
        arrcountry.append(dictionarycountry)
        
    }
    func state(withcountryid countryid:String,withstateid stateid:String,withstate state:String){
       
            let dictionarystate:[String:String] = ["countryid":countryid,"stateid":stateid,"state":state]
            arrstate.append(dictionarystate)
       
    }
    func city(withcountryid countryid:String,withstateid stateid:String,withcityid cityid:String,withcity city:String){
       
            let dictionarycity:[String:String] = ["stateid":stateid,"cityid":cityid,"city":city]
              arrcity.append(dictionarycity)
       
       
    
    }
  
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        let alertvc:UIAlertController = UIAlertController.init(title: "Error", message: "Enter data", preferredStyle:UIAlertControllerStyle.alert)
        if (txtbdate.text?.isEmpty)!{
            let altbdate:UIAlertAction = UIAlertAction.init(title: "select bdate", style: UIAlertActionStyle.default) { (action) in
                print("select bdate")
            }
            alertvc.addAction(altbdate)
            self.present(alertvc, animated: true, completion: nil)
        }else if (txtcountry.text?.isEmpty)!{
            let altcounty:UIAlertAction = UIAlertAction.init(title: "select contry", style: UIAlertActionStyle.default) { (action) in
                print("select contry")
            }
            alertvc.addAction(altcounty)
            self.present(alertvc, animated: true, completion: nil)
        }else if(txtstate.text?.isEmpty)!{
            let altstate:UIAlertAction = UIAlertAction.init(title: "select state", style: .default) { (action) in
                print("select state")
            }
            alertvc.addAction(altstate)
            self.present(alertvc, animated: true, completion: nil)
        }else if (txtcity.text?.isEmpty)!{
            let altcity:UIAlertAction = UIAlertAction.init(title: "select city", style: .default) { (action) in
                print("select city")
            }
            alertvc.addAction(altcity)
            self.present(alertvc, animated: true, completion: nil)
        }
        return true
    }
   
  /*  func textFieldDidEndEditing(_ textField: UITextField) {
        let alertvc:UIAlertController = UIAlertController.init(title: "Error", message: "Enter data", preferredStyle:UIAlertControllerStyle.alert)
        if (txtbdate.text?.isEmpty)!{
            let altbdate:UIAlertAction = UIAlertAction.init(title: "select bdate", style: UIAlertActionStyle.default) { (action) in
                print("select bdate")
            }
            alertvc.addAction(altbdate)
            self.present(alertvc, animated: true, completion: nil)
        }else if (txtcountry.text?.isEmpty)!{
            let altcounty:UIAlertAction = UIAlertAction.init(title: "select contry", style: UIAlertActionStyle.default) { (action) in
                print("select contry")
            }
            alertvc.addAction(altcounty)
            self.present(alertvc, animated: true, completion: nil)
        }else if(txtstate.text?.isEmpty)!{
            let altstate:UIAlertAction = UIAlertAction.init(title: "select state", style: .default) { (action) in
                print("select state")
            }
            alertvc.addAction(altstate)
            self.present(alertvc, animated: true, completion: nil)
        }else if (txtcity.text?.isEmpty)!{
            let altcity:UIAlertAction = UIAlertAction.init(title: "select city", style: .default) { (action) in
                print("select city")
            }
            alertvc.addAction(altcity)
            self.present(alertvc, animated: true, completion: nil)
        }
        
    }*/
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        /*if (component == 0){
            country = 1
            return arrtempcountry.count
        }
        if (component == 1){
            state = 2
            return arrtempstate.count
        }
        if (component == 2){
            city = 3
            return arrtempcity.count
        }*/
       
        if (txtcountry.isFirstResponder){
            pickerView.tag = 1
            return arrtempcountry.count
        }
        if txtstate.isFirstResponder{
            pickerView.tag = 2
           return arrtempstate.count
        }
        if txtcity.isFirstResponder{
           pickerView.tag = 3
            return arrtempcity.count
        }
        return 0
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
       /* if (component == 0){
            country = 1
            return "\(arrtempcountry[row])"
        }
        if (component == 1){
            state = 2
            return "\(arrtempstate[row])"
        }
        if (component == 2){
            city = 3
            return "\(arrtempcity[row])"
        }*/
        if (txtcountry.isFirstResponder){
            
            //txtcountry.text = "\(arrtempcountry[0])"
           return "\(arrtempcountry[row])"
        }
        if txtstate.isFirstResponder{
            print(arrtempstate)
            
           // txtstate.text = "\(arrtempstate[row])"
            return "\(arrtempstate[row])"
        }
        if txtcity.isFirstResponder{
            print(arrtempcity)
           
           // txtcity.text = "\(arrtempcity[row])"
            return "\(arrtempcity[row])"
        }
        return nil
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
          dateformatter.dateFormat = "dd/MM/yyyy"
        txtbdate.text = dateformatter.string(from: datepickerview.date)
        let newdate:Date = dateformatter.date(from: txtbdate.text!)!
        let diff = Calendar.current.dateComponents([.day], from: newdate, to: currentdate)
        lbldiff.text = "\(String(describing: diff.day!))" as String
        
        var countrykey:String!
        var countryvalue:String!
        var statekey:String!
        var statevalue:String!
        var citykey:String!
        var cityvalue:String!
        if (pickerView.tag == 1){
            
            txtstate.text = "\(arrstate[0])"
            txtcity.text = "\(arrcity[0])"
            let txtdata = arrcountry[row]
            txtcountry.text = "\(txtdata)"
            arrtempstate = []
           // print(txtdata)
          //  print("\(txtcountry.text)")
           /* for obj in arrcountry{
                if (obj == txtdata){
                    arrtempcountry.append(txtdata)
                    print(arrtempcountry)
                    break
                    }
            }*/
                //for objcountry in txtdata{
                    for (key,value) in txtdata{
                        countrykey = key
                        countryvalue = value
                        for objstate in arrstate{
                            for (key,value) in objstate{
                                statekey = key
                                statevalue = value
                                if (countrykey == statekey) && (countryvalue == statevalue){
                                    arrtempstate.append(objstate)
                                  //  print(arrtempstate)
                                }
                            }
                        }
                    }
                }
 //           }
        
        if (pickerView.tag == 2){
            txtstate.text = "\(arrstate[0])"
            txtcity.text = "\(arrcity[0])"
            let txtdata = arrtempstate[row]
            txtstate.text = "\(txtdata)"
            arrtempcity = []
            txtcity.text=""
          //  print(txtdata)
        //    print("\(txtstate.text)")
           
            for (key,value) in txtdata{
                statekey = key
                statevalue = value
                for objcity in arrcity{
                    for (key,value) in objcity{
                        citykey = key
                        cityvalue = value
                        if (statekey == citykey) && (statevalue == cityvalue){
                            arrtempcity.append(objcity)
                           // print(arrtempcity)
                        }
                    }
                }
            }
            
        }
        if (pickerView.tag == 3){
            txtcity.text = "\(arrtempcity[row])"
        }
        
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
            self.pickerview.isHidden = false
            return true
    }
   
    func textFieldDidBeginEditing(_ textField: UITextField) {
        pickerview.reloadAllComponents()
    }

@IBAction func btnprint(){
    
    
 //  let dateformatter:DateFormatter = DateFormatter()
//    dateformatter.dateFormat = "dd/MM/yyyy"
 //   txtbdate.text = dateformatter.string(from: datepickerview.date)
//    let newdate:Date = dateformatter.date(from: txtbdate.text!)!
//    let diff = Calendar.current.dateComponents([.day], from: newdate, to: currentdate)
//    let diff = Calendar.current.dateComponents([.day.month.year], from: newdate, to: currentdate)
    //diff.yearForWeekOfYear
   // txtcountry.text = "\(country)"
    //txtstate.text = "\(state)"
    //txtcity.text = "\(city)"
    //lbldiff.text = "\(String(describing: diff.day))"
    //"Year :: \(String(describing: diff.year!)) Month :: \(String(describing: diff.month!)) Day :: \(String(describing: diff.day!)) "
}

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}



