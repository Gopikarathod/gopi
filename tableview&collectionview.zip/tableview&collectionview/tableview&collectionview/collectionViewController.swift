//
//  collectionViewController.swift
//  tableview&collectionview
//
//  Created by agile-10 on 28/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class collectionViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    
    
    @IBOutlet var coollection:UICollectionView!
    let objapp = UIApplication.shared.delegate as? AppDelegate

    var arrColl:[String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        coollection.dataSource = self
        coollection.delegate = self
        arrColl = (objapp?.arrcoll)!
        // Do any additional setup after loading the view.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print(arrColl)
        return arrColl.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell:CollectionViewCell = (collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as? CollectionViewCell)!
        
        let objcoll  = arrColl[indexPath.row]
        
            cell.collImage.image = UIImage.init(named:objcoll)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.width
        return CGSize.init(width: width/4, height: width/4)
    
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
