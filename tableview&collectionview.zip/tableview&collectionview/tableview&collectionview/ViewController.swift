//
//  ViewController.swift
//  tableview&collectionview
//
//  Created by agile-10 on 28/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
  
    
    @IBOutlet var tblview:UITableView!
    let objapp = UIApplication.shared.delegate as? AppDelegate
    
    let arrimage:[String] = ["1.jpg","2.jpg","3.png","4.jpg","5.jpg"]

    override func viewDidLoad() {
        super.viewDidLoad()
        tblview.delegate = self
        tblview.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrimage.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = (tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as? TableViewCell)!
        
        let objname:String = arrimage[indexPath.row]
        
        cell.img.image = UIImage.init(named:"\(objname)")
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let objarrname = arrimage[indexPath.row]
        
            objapp?.arrcoll.append(objarrname)

        let objcollview:collectionViewController = (storyboard?.instantiateViewController(withIdentifier: "collectionViewController") as? collectionViewController)!
      
        
        navigationController?.pushViewController(objcollview, animated: true)
  
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

