//
//  historyViewController.swift
//  FinalExam
//
//  Created by agile-10 on 03/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class historyViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
   
    
    
    let objapp = UIApplication.shared.delegate as? AppDelegate
    @IBOutlet var tblhistory:UITableView!
    var arr:[[String:Any]] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        let objadd:addRecordViewController = addRecordViewController()
        objadd.fetchRecord()
        
        arr = (objapp?.arrRecord)!
        
        tblhistory.delegate = self
        tblhistory.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(arr)
       // return (objapp?.arrRecord.count)!
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if  let cell:historyTableViewCell = (tableView.dequeueReusableCell(withIdentifier: "historyTableViewCell") as! historyTableViewCell){
            
            let formate:DateFormatter = DateFormatter()
            formate.dateFormat = "yyyy-MM-dd "
            formate.timeZone = NSTimeZone.init(abbreviation: "GMT")! as TimeZone
            let objarr = arr[indexPath.row]
            let objstr = formate.string(from: objarr["date"] as! Date)
           
       
            cell.lbldate.text = objstr
            cell.lbldesc.text = objarr["description"] as? String
            cell.lblamt.text =  "\(String(describing: objarr["amount"]!))"

        return cell
        }
        return UITableViewCell()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
