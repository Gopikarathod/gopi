//
//  ViewController.swift
//  FinalExam
//
//  Created by agile-10 on 03/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var txtdate:UITextField!
    @IBOutlet var lblIncome:UILabel!
    @IBOutlet var lblExpence:UILabel!
    @IBOutlet var lbltotal:UILabel!
    let objapp = UIApplication.shared.delegate as? AppDelegate

    override func viewDidLoad() {
        super.viewDidLoad()
        let objadd:addRecordViewController = addRecordViewController()
        let dateFormatter:DateFormatter = DateFormatter()
        let date = Date()
        dateFormatter.dateFormat = "MMMM"
        let currentdate = dateFormatter.string(from: date)
        txtdate.text = currentdate
        objadd.fetchRecord()
        var amt = 0
        var amtex = 0
        for i in (objapp?.arrRecord)!{
            
            let objamt:Int? = i["amount"] as? Int
            
            let type:Int? = i["typeid"] as? Int
            if type == 1 {
                amt = amt + objamt!
                lblIncome.text = "\(String(describing: amt))"
            }else{
                amtex = amtex + objamt!
                lblExpence.text = "\(String(describing: amtex))"
            }
            
            let total = amt - amtex
            lbltotal.text = "\(total)"
            
            if amt > amtex {
                view.backgroundColor = UIColor.red
               self.view.tintColor = UIColor.white
                
            }else{
                view.backgroundColor = UIColor.green
                self.view.tintColor = UIColor.white

            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        viewDidLoad()
    }
   
   
    @IBAction func btnadd(_ sender: Any) {
        
       self.actionSheetAdd()
    }
    
    func actionSheetAdd(){
        let alertvc:UIAlertController = UIAlertController.init(title: "Title", message: "Lorem ipsum dolor sit amet", preferredStyle:UIAlertControllerStyle.actionSheet)
        
        
        let altIncome:UIAlertAction = UIAlertAction.init(title: "Income", style: .default) { (action) in
            let objadd:addRecordViewController = (self.storyboard?.instantiateViewController(withIdentifier: "addRecordViewController") as? addRecordViewController)!
            objadd.title = "Income"
            objadd.str = "income"
            self.navigationController?.pushViewController(objadd, animated: true)
        }
        
        
        let altExpence:UIAlertAction = UIAlertAction.init(title: "Expence", style: UIAlertActionStyle.default) { (action) in
            let objadd:addRecordViewController = (self.storyboard?.instantiateViewController(withIdentifier: "addRecordViewController") as? addRecordViewController)!
            objadd.title = "Expence"
            objadd.str = "expence"
            self.navigationController?.pushViewController(objadd, animated: true)
        }
        
        let altCancle:UIAlertAction = UIAlertAction.init(title: "Cancle", style: .cancel)
        
        alertvc.addAction(altIncome)
        altExpence.setValue(UIColor.red, forKey: "titleTextColor")
        alertvc.addAction(altExpence)
        alertvc.addAction(altCancle)
        self.present(alertvc, animated: true, completion: nil)
        
    }
    
    func actionSheetType(){
        
        let alertvc:UIAlertController = UIAlertController.init(title: "Title", message: "Lorem ipsum dolor sit amet", preferredStyle:UIAlertControllerStyle.actionSheet)
      
        
        let altIncome:UIAlertAction = UIAlertAction.init(title: "Income", style: .default) { (action) in
            let objadd:addTypeViewController = (self.storyboard?.instantiateViewController(withIdentifier: "addTypeViewController") as? addTypeViewController)!
            objadd.title = "Income"
            objadd.str = "Income"
            self.navigationController?.pushViewController(objadd, animated: true)
        }
        
        let altExpence:UIAlertAction = UIAlertAction.init(title: "Expence", style: UIAlertActionStyle.default) { (action) in
            let objadd:addTypeViewController = (self.storyboard?.instantiateViewController(withIdentifier: "addTypeViewController") as? addTypeViewController)!
            objadd.title = "Expence"
            objadd.str = "Expence"
            self.navigationController?.pushViewController(objadd, animated: true)
        }
  
        let altCancle:UIAlertAction = UIAlertAction.init(title: "Cancle", style: .cancel)
        
        alertvc.addAction(altIncome)
        altExpence.setValue(UIColor.red, forKey: "titleTextColor")
        alertvc.addAction(altExpence)
        alertvc.addAction(altCancle)
         self.present(alertvc, animated: true, completion: nil)
        
    }
    @IBAction func btnType(_ sender: UIButton) {
         self.actionSheetType()
        
    }
    
    @IBAction func btnHistory(_ sender: UIButton) {
        
        let objhistory:historyViewController = (self.storyboard?.instantiateViewController(withIdentifier: "historyViewController") as? historyViewController)!
        navigationController?.pushViewController(objhistory, animated: true)
    }
    override func didReceiveMemoryWarning() {
       
        
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

