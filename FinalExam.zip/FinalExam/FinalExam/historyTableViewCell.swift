//
//  historyTableViewCell.swift
//  FinalExam
//
//  Created by agile-10 on 04/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class historyTableViewCell: UITableViewCell {
    @IBOutlet var lbldate:UILabel!
    @IBOutlet var lbldesc:UILabel!
    @IBOutlet var lblamt:UILabel!


    override func awakeFromNib() {
        super.awakeFromNib()
       
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
