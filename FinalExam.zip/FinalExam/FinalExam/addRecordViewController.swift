//
//  addRecordViewController.swift
//  FinalExam
//
//  Created by agile-10 on 03/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import CoreData
class addRecordViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate{
   

    @IBOutlet var txtdate:UITextField!
    @IBOutlet var txtType:UITextField!
    @IBOutlet var txtAmount:UITextField!
    @IBOutlet var txtdescription:UITextField!
    @IBOutlet var myview:UIView!
    var datepicker = UIDatePicker()
    var str:String = ""
    var format:DateFormatter = DateFormatter()
    var currentdate = Date()
    var typeid:Int!
    var arrIncome:[String] = ["salary","gift","pocketMoney"]
    var arrExpence:[String] = ["food","petrol","rent","shoppeing"]
    var Dict:[String:Any] = [:]


    override func viewDidLoad() {
        super.viewDidLoad()
        print(currentdate)
        format.dateFormat = "yyyy-MM-dd"
        datepicker.datePickerMode = .date
        txtdate.text = format.string(from: currentdate)
        
       txtdescription.delegate = self

        // Do any additional setup after loading the view.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtdescription.resignFirstResponder()
        return true
    }
    
    @IBAction func btndatepicker(_ sender: Any) {
        txtdate.inputView = datepicker
        let dates = Calendar.current.dateComponents([.month,.day,.year], from: currentdate)
    
        guard let maximum = Calendar.current.date(from: dates) else {
            fatalError("Couldn't get next year")
        }
        
        datepicker.maximumDate = maximum
        
        datepicker.addTarget(self, action: #selector(pickerView(_:didSelectRow:inComponent:)), for: .valueChanged)
        
    }
    @IBAction func btnpicker(_ sender: UIButton) {
       
        let picker = UIPickerView.init(frame: CGRect.init(x: 0, y: 100, width: view.frame.width, height: 100))
        picker.delegate = self
        picker.dataSource = self
        txtType.inputView = picker
        
    }
    

    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if (txtType.isFirstResponder){
            if str == "income"{
                 return arrIncome.count
            }else{
                return arrExpence.count

            }
           
        }
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if (txtType.isFirstResponder){
            if str == "income"{
                return arrIncome[row]
            }else{
                return arrExpence[row]
            }
        }
        return nil
    }
        
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
         txtdate.text = format.string(from: datepicker.date)
        
        if (txtType.isFirstResponder){
            if str == "income"{
                txtType.text = arrIncome[row]
            }else{
                txtType.text = arrExpence[row]
                
            }
        }
        
    }
    
    func insertDataInCoreDatabase(){
        
        if (str == "income"){
            typeid = 1
        }else{
            typeid = 2
        }
        
        guard let objapp = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        let formate:DateFormatter = DateFormatter()
        formate.dateFormat = "yyyy-MM-dd "
        formate.timeZone = NSTimeZone.init(abbreviation: "GMT")! as TimeZone
        let textdate:String = self.txtdate.text! 
        let dd  = formate.date(from:textdate)
        let amt:Int?  = Int(txtAmount.text!)
        Dict = ["date":dd! ,"id":(objapp.arrRecord.count + 1) ,"amount":amt ?? "","description":txtdescription.text ?? "","typeid":typeid]
        
        print(Dict)

        
        let manageContext = objapp.persistentContainer.viewContext
        
        let Entity:NSEntityDescription = NSEntityDescription.entity(forEntityName: "Tbltransaction", in: manageContext)!
        
        let attribute:NSManagedObject = NSManagedObject.init(entity: Entity, insertInto: manageContext)
        
        attribute.setValue(Dict["date"], forKey: "date")
        attribute.setValue(Dict["id"], forKey: "id")
        attribute.setValue(Dict["amount"], forKey: "amount")
        attribute.setValue(Dict["description"], forKey: "descrip")
        attribute.setValue(Dict["typeid"], forKey: "typeid")
        do{
            try manageContext.save()
            print("save data")
        }
        catch{
            print(error.localizedDescription)
        }
        txtAmount.text = ""
        txtType.text = ""
        txtdescription.text = ""
    }
    
    func fetchRecord(){
    
    guard  let objapp = UIApplication.shared.delegate as? AppDelegate else {
    return
    }
    let managecontext = objapp.persistentContainer.viewContext
    let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Tbltransaction")
        
   
    
    do{
    
    let data = try managecontext.fetch(fetchRequest)
    
    for user in data {
    
    Dict["date"] = user.value(forKey: "date")
    Dict["id"] = user.value(forKey: "id")
    Dict["description"] = user.value(forKey: "descrip")
    Dict["amount"] = user.value(forKey: "amount")
    Dict["typeid"] = user.value(forKey: "typeid")
    
    objapp.arrRecord.append(Dict)
        print(objapp.arrRecord)
    
    }
    
    } catch{
    print(error.localizedDescription)
    }
        
}
    

    

    @IBAction func btnAdd(_ sender: UIButton) {
        
        if(txtType.text?.isEmpty)! || (txtAmount.text?.isEmpty)! || (txtdescription.text?.isEmpty)!{
            print("blanck record")
        }else{
            
            insertDataInCoreDatabase()
            fetchRecord()

        }
    }
    

}
