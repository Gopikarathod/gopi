//
//  addTypeViewController.swift
//  FinalExam
//
//  Created by agile-10 on 03/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import CoreData

class addTypeViewController: UIViewController,UITextFieldDelegate{
    
    var str:String = ""
    var typeid:Int!
    var Dict:[String:Any] = [:]
    @IBOutlet var txtid:UITextField!
    @IBOutlet var txttype:UITextField!
    @IBOutlet var txttypename:UITextField!
    var arrincome:[[String:Any]] = []
    var arrexpen:[[String:Any]] = []
   

    override func viewDidLoad() {
        super.viewDidLoad()
           fetchRecord()
        print(arrincome)
        print(arrexpen)
        if (str == "Income"){
            txtid.text = "\(arrincome.count + 1)"
        }else{
            txtid.text = "\(arrexpen.count + 1)"
        }
        
      
        txttypename.delegate = self
        txttype.text = str
        txtid.isEnabled = false
        
        
        

        // Do any additional setup after loading the view.
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txttypename.resignFirstResponder()
        
        return true
    }
    func fetchRecord(){
        
        guard  let objapp = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managecontext = objapp.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Tbltype")
        
        
        
        do{
            
            let data = try managecontext.fetch(fetchRequest)
            
            for user in data {
            
                Dict["id"] = user.value(forKey: "id")
                Dict["Type"] = user.value(forKey: "typename")
                Dict["typeid"] = user.value(forKey: "transactiontype")
                let objtypeid:Int = Dict["typeid"] as! Int
                
                if objtypeid == 1{
                    arrincome.append(Dict)
                }else{
                    arrexpen.append(Dict)
                }
            }
            
        } catch{
            print(error.localizedDescription)
        }
        
    }
    
    func insertDataInCoreDatabase(){
        
        if (str == "Income"){
            typeid = 1
        }else{
            typeid = 2
        }
        
        guard let objapp = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        
        let id:Int? = Int(txtid.text!)
        
        Dict = ["id":id ?? "" ,"Type":txttypename.text ?? "","typeid":typeid]
        
        print(Dict)
        
        
        let manageContext = objapp.persistentContainer.viewContext
        
        let Entity:NSEntityDescription = NSEntityDescription.entity(forEntityName: "Tbltype", in: manageContext)!
        
        let attribute:NSManagedObject = NSManagedObject.init(entity: Entity, insertInto: manageContext)
        
        attribute.setValue(Dict["id"], forKey: "id")
        attribute.setValue(Dict["typeid"], forKey: "transactiontype")
        attribute.setValue(Dict["Type"], forKey: "typename")
        
        do{
            try manageContext.save()
            print("save data")
            let objadd:addRecordViewController = addRecordViewController()
            if (str == "Income"){
                objadd.arrIncome.append(Dict["Type"] as! String)
            }else{
                objadd.arrExpence.append(Dict["Type"] as! String)
            }
        }
        catch{
            print(error.localizedDescription)
        }
        txttypename.text = ""
    }


    @IBAction func btnAddType(_ sender: UIButton) {
        
        if (txttypename.text?.isEmpty)!{
            print("enter data")
        }else{
            insertDataInCoreDatabase()

        }
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
