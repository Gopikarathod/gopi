//
//  mapAnnotationview.swift
//  map
//
//  Created by agile-10 on 25/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import  MapKit

class mapAnnotationview: NSObject,MKAnnotation{
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?

    init(withcoordinate location:CLLocationCoordinate2D) {
        self.coordinate = location
        self.title = "ElisBridge"
        self.subtitle = "Wel-Come"
    }
    

}
