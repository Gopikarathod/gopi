//
//  ViewController.swift
//  map
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

  class maplocation: NSObject,MKAnnotation{
    
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    var isDisplayCallout:Bool = false
    
     init(mitcoordinate: CLLocationCoordinate2D,mittitle: String?,mitsubtitle: String?) {
        
        self.coordinate = mitcoordinate
        self.title = mittitle
        self.subtitle = mitsubtitle
        super.init()
        
    }
}

class ViewController: UIViewController,MKMapViewDelegate{
    
    @IBOutlet var map:MKMapView!
    let regionRedius:CLLocationDistance = 1000
    let obj:CLLocationManager = CLLocationManager()
    let coordinateAbad = CLLocationCoordinate2D(latitude: 23.0225, longitude: 72.5714)
    let coordinate = CLLocationCoordinate2DMake(56.1304, 106.3468)
    override func viewDidLoad() {
        super.viewDidLoad()
       map.delegate = self
        checkOnAuthorizationStatus()
        
        let mitannotation = maplocation.init(mitcoordinate: coordinateAbad, mittitle: "Ahmedabad", mitsubtitle: "abad")
        
        let mitannotation1 = maplocation.init(mitcoordinate: coordinate, mittitle: "Canada", mitsubtitle: "WEl-come")
        mitannotation.isDisplayCallout = true
    
//let mitmapannotation = mapAnnotationview.init(withcoordinate: coordinate)
        map.addAnnotation(mitannotation)
        map.addAnnotation(mitannotation1)
//centerMapOnLocation(location: coordinate)
        
        
       // Do any additional setup after loading the view, typically from a nib.
}
    
    func checkOnAuthorizationStatus(){
        if CLLocationManager.locationServicesEnabled() == true {
            if(CLLocationManager.authorizationStatus() == .authorizedWhenInUse || CLLocationManager.authorizationStatus() == .authorizedAlways || CLLocationManager.authorizationStatus() == .notDetermined){
                
                obj.requestAlwaysAuthorization()
                obj.requestWhenInUseAuthorization()
                map.showsUserLocation = true
                
               
            } else {
            obj.requestAlwaysAuthorization()
              UIApplication.shared.open(URL(string:UIApplicationOpenSettingsURLString)!)
            }
        }
    }
    
func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
     guard let annotation = annotation as? maplocation else{return nil}
    var view:MKMarkerAnnotationView
    let identifier = "maplocation"
    
    if let dequreusble = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKMarkerAnnotationView{
        dequreusble.annotation = annotation
        view = dequreusble
        
    }
    else {
        view = MKMarkerAnnotationView.init(annotation: annotation, reuseIdentifier: identifier)
      //  view.titleVisibility = .visible
        view.glyphText = annotation.subtitle
        view.canShowCallout = annotation.isDisplayCallout
        view.calloutOffset = CGPoint.init(x: -5, y: 5)
        view.rightCalloutAccessoryView = UIButton.init(type: .detailDisclosure)
    }
        return view

    }
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if let annotation = view.annotation as? maplocation{
             print(annotation.coordinate)        
            
        }
       
    }
    
    func centerMapOnLocation(location:CLLocationCoordinate2D){
        let region = MKCoordinateRegionMakeWithDistance(location, regionRedius, regionRedius)
    
        map.setRegion(region, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

