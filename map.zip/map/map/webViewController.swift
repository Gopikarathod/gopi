//
//  webViewController.swift
//  map
//
//  Created by agile-10 on 25/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import WebKit

class webViewController: UIViewController,WKNavigationDelegate,WKUIDelegate{
    
    @IBOutlet var objwebview:WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad")
        
        objwebview.navigationDelegate = self
        objwebview.uiDelegate = self
        
       let strname:String = "<HTML><HEAD></HEAD><body><h1>Hello World</h1></body></HTML>"
        objwebview.loadHTMLString(strname, baseURL: nil)

//        objwebview.load(URLRequest.init(url: URL.init(string: "https://www.youtube.com/results?search_query=maplocation+annotationview+in+swift")!))
        
        
        
        /*objwebview.loadFileURL(URL.init(fileURLWithPath: "mapfile"), allowingReadAccessTo: URL.init(string: "mapfile")!)*/
     /*   do {
        let stn:String = Bundle.main.path(forResource: "myhtml", ofType: "html")!
        let url:String = try String.init(contentsOf: URL.init(fileURLWithPath: stn))
        
        objwebview.loadHTMLString(url, baseURL: nil)
        }catch{
            print(Error.self)
        }*/
      /*  let path = NSURL.init(fileURLWithPath: "mapfile.html")
        let req = NSURLRequest.init(url: path as URL)
        objwebview.load(req as URLRequest)*/
        
        

        // Do any additional setup after loading the view.
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { // 1
        print("didStartProvisionalNavigation navigation")
    }
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        print("didReceiveServerRedirectForProvisionalNavigation")
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print("didFailProvisionalNavigation")
    }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {//2
        print("didCommit")
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {//3
        print("didFinish")
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("didFail")
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        print("webViewWebContentProcessDidTerminate")
    }
    
   @IBAction func btnMapview(){
    let objmapview:ViewController = (storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController)!
    self.navigationController?.pushViewController(objmapview, animated: true)
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        print("didReceiveMemoryWarning")
        // Dispose of any resources that can be recreated.
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
