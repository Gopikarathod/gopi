//
//  ViewController.swift
//  calculater
//
//  Created by agile-10 on 27/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblcal: UILabel!
    var num1:Float=0
    var per:Float=0
    var performingMath = false
    var opration=0;
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        lblcal.adjustsFontSizeToFitWidth = true
    }

    @IBAction func btnOpration(_ sender: UIButton) {
        if lblcal.text != "" && sender.tag != 15 && sender.tag != 17 {
            per = Float(lblcal.text!)!
            
            if sender.tag == 11
            {
                lblcal.text =  "/"
            }else if sender.tag == 12
            {
               lblcal.text = "*"
            }else if sender.tag == 13
            {
                lblcal.text = "-"
            }else if sender.tag == 14
            {
                lblcal.text = "+"
            }
            
            opration = sender.tag
            performingMath = true
        
         }else if (sender.tag == 15){
            
            if opration == 11
            {
                lblcal.text =  "\(num1 / per)"
            }else if opration == 12
            {
                lblcal.text = "\(num1 * per)"
            }else if opration == 13
            {
                lblcal.text = "\(num1 - per)"
            }else if opration == 14
            {
                lblcal.text = "\(num1 + per)"
            }
            
        } else if (sender.tag == 16){
            lblcal.text = ""
            num1 = 0
            per = 0
            opration = 0
        }
        
    }
    
    
    @IBAction func btnDigit(_ sender: UIButton) {
        
        if (performingMath == true){
            lblcal.text =  String(sender.tag-1)
            num1 = Float(lblcal.text!)!
            performingMath = false
        }else
        {
            lblcal.text =  lblcal.text! + String(sender.tag-1)
            num1 = Float(lblcal.text!)!
        }
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

