//
//  PickerData.h
//  picker_pract
//
//  Created by agile-14 on 20/09/16.
//  Copyright (c) 2016 agile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PickerData : NSObject

@property (strong, nonatomic) NSArray *main;

-(NSInteger)getNumberOfState : (NSString *) country;
-(NSInteger)getNumberOfCity : (NSString *)state ForCountry: (NSString *) country;

-(NSString*)getCountryName : (NSInteger)Index;
-(NSString *)getStateName : (NSInteger)Index ForCountry: (NSString *) country;
-(NSString *)getCityName : (NSInteger)Index ForCountry: (NSString *) country  ForState : (NSString*) state;

@end
