//
//  ViewController.m
//  picker_pract
//
//  Created by agilemac-151 on 9/5/16.
//  Copyright © 2016 agile. All rights reserved.
//

#import "ViewController.h"
#import "PickerData.h"

@interface ViewController ()
{
    PickerData *pickerData;
    NSString *selectedCountry;
    NSString *selectedState;
    NSString *selectedCity;
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    pickerData = [[PickerData alloc] init];
    
    NSDictionary *countryDict = [pickerData.main objectAtIndex:0];
    
    selectedCountry = [countryDict valueForKey:@"country"];
    NSDictionary *stateDict = [countryDict valueForKey:@"state"];
    selectedState = [[stateDict allKeys] objectAtIndex:0];

}
#pragma mark- picker required method
// returns the number of 'columns' to display.
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    
    return 3;
}

// returns the # of rows in each component..
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
  
    if (component == 0) {
        return pickerData.main.count;
    }
    
    if (component == 1) {
        return [pickerData getNumberOfState:selectedCountry];
    }
    
    if (component == 2) {
        return [pickerData getNumberOfCity:selectedState ForCountry:selectedCountry];
    }
    return 5;
}


- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    
    if (component == 0) {
        return [pickerData getCountryName:row];
    }
    
    if (component == 1) {
        return [pickerData getStateName:row ForCountry:selectedCountry];
    }
    
    if (component == 2) {
        return [pickerData getCityName:row ForCountry:selectedCountry ForState:selectedState];
    }
    return @"";
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    
    selectedCountry = [pickerData getCountryName:[pickerView selectedRowInComponent:0]];
    countryTxt.text = selectedCountry;
    
    [pickerView reloadComponent:1];
    
    selectedState = [pickerData getStateName:[pickerView selectedRowInComponent:1] ForCountry:selectedCountry];
    stateTxt.text = selectedState;
    
    [pickerView reloadComponent:2];
    
    selectedCity = [pickerData getCityName:[pickerView selectedRowInComponent:2] ForCountry:selectedCountry ForState:selectedState];
    cityTxt.text = selectedCity;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
