//
//  ViewController.h
//  picker_pract
//
//  Created by agilemac-151 on 9/5/16.
//  Copyright © 2016 agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    IBOutlet UITextField *countryTxt;
    IBOutlet UITextField *stateTxt;
    IBOutlet UITextField *cityTxt;
    IBOutlet UIPickerView *pickerView;

}

@end

