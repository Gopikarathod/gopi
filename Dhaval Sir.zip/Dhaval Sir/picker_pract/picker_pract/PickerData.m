//
//  PickerData.m
//  picker_pract
//
//  Created by agile-14 on 20/09/16.
//  Copyright (c) 2016 agile. All rights reserved.
//

#import "PickerData.h"

@implementation PickerData

- (instancetype)init
{
    self = [super init];
    if (self) {
        _main = @[
                 @{
                     @"country" : @"India",
                     @"state": @{
                             @"GJ" : @[@"AMD",@"JMR",@"RJK"],
                             @"MH" : @[@"MUB",@"PUN",@"NSK"],
                             @"RJ" : @[@"JPR",@"UDP",@"AJM"]
                             },
                     },
                 
                 @{
                     @"country" : @"US",
                     @"state": @{
                             @"US1" : @[@"US11",@"US12",@"US13"],
                             @"US2" : @[@"US21",@"US22",@"US23"],
                             @"US3" : @[@"US31",@"US32",@"US33"]
                             },
                     },
                 @{
                     @"country" : @"UK",
                     @"state": @{
                             @"UK1" : @[@"UK11",@"UK12",@"UK13"],
                             @"UK2" : @[@"UK21",@"UK22",@"UK23"],
                             @"UK3" : @[@"UK31",@"UK32",@"UK33"]
                             },
                     },
                 @{
                     @"country" : @"RSA",
                     @"state": @{
                             @"RSA1" : @[@"RSA11",@"RSA12",@"RSA13"],
                             @"RSA2" : @[@"RSA21",@"RSA22",@"RSA23"],
                             @"RSA3" : @[@"RSA31",@"RSA32",@"RSA33"]
                             },
                     },
                 @{
                     @"country" : @"CHN",
                     @"state": @{
                             @"CHN1" : @[@"CHN11",@"CHN12",@"CHN13"],
                             @"CHN2" : @[@"CHN21",@"CHN22",@"CHN23"],
                             @"CHN3" : @[@"CHN31",@"CHN32",@"CHN33"]
                             },
                     },
                 ];
    }
    return self;
}

-(NSInteger)getNumberOfState : (NSString *)country {
    NSInteger cnt = 0 ;
    for (NSDictionary *countryDict in self.main) {
        if ([country isEqual:[countryDict valueForKey:@"country"]]) {
            NSDictionary *stateDict = [countryDict valueForKey:@"state"];
           cnt = [[stateDict allKeys]count];
        }
    }
    return cnt;
}


-(NSInteger)getNumberOfCity : (NSString *)state ForCountry: (NSString *) country{

    NSInteger cnt = 0 ;
    
    for (NSDictionary *countryDict in self.main) {
        if ([country isEqual:[countryDict valueForKey:@"country"]]) {

            NSDictionary *stateDict = [countryDict valueForKey:@"state"];
            
            if ([stateDict objectForKey:state]) {
                NSArray * cityDict = [stateDict objectForKey:state];
                cnt = cityDict.count;
            }
        }
    } 
    
    
    return cnt;
}

-(NSString*)getCountryName : (NSInteger)Index {
    
    NSDictionary *countryNameDict = [self.main objectAtIndex:Index];
    
     return countryNameDict[@"country"];
}

-(NSString *)getStateName : (NSInteger)Index ForCountry: (NSString *) country {
    
    NSString *cnt ;
    for (NSDictionary *countryDict in self.main) {
        if ([country isEqual:[countryDict valueForKey:@"country"]]) {
            NSDictionary *stateDict = [countryDict valueForKey:@"state"];
            cnt = [[stateDict allKeys]objectAtIndex:Index];
        }
    }
    return cnt;
}

-(NSString *)getCityName : (NSInteger)Index ForCountry: (NSString *) country  ForState : (NSString*) state{
    
    NSString *cnt;
    
    for (NSDictionary *countryDict in self.main) {
        if ([country isEqual:[countryDict valueForKey:@"country"]]) {
            
            NSDictionary *stateDict = [countryDict valueForKey:@"state"];
            
            if ([stateDict objectForKey:state]) {
                NSArray * cityDict = [stateDict objectForKey:state];
               cnt = [cityDict objectAtIndex:Index];
    
            }
            
            
        }
    }
    return cnt;
}

@end
