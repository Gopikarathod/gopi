//
//  AppDelegate.h
//  picker_pract
//
//  Created by agilemac-151 on 9/5/16.
//  Copyright © 2016 agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

