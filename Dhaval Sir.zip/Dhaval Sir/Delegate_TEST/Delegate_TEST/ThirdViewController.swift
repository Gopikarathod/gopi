//
//  ThirdViewController.swift
//  Delegate_TEST
//
//  Created by agilemac-74 on 24/08/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnGoToFourthVCPressed(_ sender: Any) {
        
        let fourthVC = self.storyboard?.instantiateViewController(withIdentifier: "FourthViewController") as! FourthViewController
        self.navigationController?.pushViewController(fourthVC, animated: true)
    }

}
