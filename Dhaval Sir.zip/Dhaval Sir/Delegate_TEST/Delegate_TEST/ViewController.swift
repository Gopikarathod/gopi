//
//  ViewController.swift
//  Delegate_TEST
//
//  Created by agilemac-74 on 22/08/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

protocol ProtocolMinLengthChecker  {
    func minLengthCheck() -> Bool
}


class ViewController: UIViewController {
    
   
    
    //MARK:- PROPERTIES
    @IBOutlet var txtNameFirst: UITextField!
    @IBOutlet var textviewFeedback: UITextView!

    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()

        doSetupUI()
    }
    
    private func doSetupUI() {

        self.txtNameFirst.delegate = self
        self.txtNameFirst.returnKeyType = UIReturnKeyType.done
        self.txtNameFirst.autocorrectionType = .no
        self.txtNameFirst.autocapitalizationType = .sentences
        self.txtNameFirst.keyboardType = .emailAddress
        
        textviewFeedback.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    

    
    //MARK:- BUTTON EVENTS
    @IBAction func btnSubmitPressed(_ sender: Any) {

        
        if minLengthCheck() {
            let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
            
            guard let navigationController = self.navigationController else {
                return
            }
            
            secondVC.name = txtNameFirst.text!
            secondVC.delegate = self
            navigationController.pushViewController(secondVC, animated: true)
        }else{
            self.displayAlert(message: "MIN 3 DIGITS REQUIRED !!")
            
//            self.displayActionsheet(message: "To select your profile picture")
            
        }
        
        
    }
    
    // MARK:- SEGUE
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let secondVC = segue.destination as! SecondViewController
        secondVC.name = sender as! String
        secondVC.delegate = self
    }
    
    
    @IBAction func segmentValueChanged(_ sender: UISegmentedControl) {
        print("Segment \(sender.selectedSegmentIndex) selected")
    }
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        
        print("Slider value = \(sender.value)  MIN : \(sender.minimumValue) MAX \(sender.maximumValue)")
    }
    
    @IBAction func stepperValuceChanged(_ sender: UIStepper) {
        
        print("Stepper = \(sender.value)")
    }
    
    @IBAction func switchValueChanged(_ sender: UISwitch) {
        print("Switch \(sender.isOn)")
    }
    
}

extension ViewController : ProtocolMinLengthChecker {
    
    //MARK:- VALIDATION
    func minLengthCheck() -> Bool {
        if let count1 = txtNameFirst.text?.count {
            let isValid = count1 >= 3
            return isValid
        }else{
            return false
        }
    }

}

extension ViewController : ProtocolSecondVCDelegate {
    
    func saveWasPerformed(editedText: String) {
        txtNameFirst.text = editedText
    }

}

extension ViewController : UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        print("SHOULD BEGIN EDITING")
        return true
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("BEGIN EDITING")
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        print("SHOULD END EDITING")
        return true
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        print("END EDITING")
    }
//    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
//        print("END EDITING WITH REASON : \(reason)")
//    }

    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        print("SHOULD CLEAR")
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print("SHOULD RETURN")
        textField.resignFirstResponder()
        
        return true
    }
    
    
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        print("SHOULD CHANGE : RANGE = \(range)  STRING = \(string)")
        
        textField.myCustomMethod()
        
        return true
    }
    
    
}
extension UITextField {
    
    func myCustomMethod() {
        
    }
}


extension ViewController : UITextViewDelegate {
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        return true
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {

        return true
    }
}

extension UIViewController {
    
    
    func displayAlert(message:String) {
        
        let alertVC = UIAlertController(title: "Validation failed !!", message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        let actionCancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.destructive) { (action) in
            print("Cancel pressed")
        }
        
        let actionOk = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) { (action) in
            print("Ok pressed")
        }
        
        
        alertVC.addAction(actionCancel)
        alertVC.addAction(actionOk)
        self.present(alertVC, animated: true, completion: nil)
        
    }
    
    
    
    func displayActionsheet(message:String) {
        
        let alertVC = UIAlertController(title: "Choose option ", message: message, preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let actionCamera = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default) { (action) in
            print("Camera pressed")
        }
        

        let actionPhotos = UIAlertAction(title: "Photos", style: UIAlertActionStyle.default) { (action) in
            print("Photos pressed")
        }
        
        let actionLibrary = UIAlertAction(title: "Library", style: UIAlertActionStyle.default) { (action) in
            print("Library pressed")
        }
        
        let actionCancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.destructive) { (action) in
            print("Cancel pressed")
        }
        
        
        alertVC.addAction(actionCamera)
        alertVC.addAction(actionPhotos)
        alertVC.addAction(actionLibrary)
        
        alertVC.addAction(actionCancel)
        
        
        self.present(alertVC, animated: true, completion: nil)
        
    }
    
    
    
    
}

