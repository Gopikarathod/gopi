//
//  SecondViewController.swift
//  Delegate_TEST
//
//  Created by agilemac-74 on 22/08/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

protocol ProtocolSecondVCDelegate {
    func saveWasPerformed(editedText:String)
}



class SecondViewController: UIViewController {
    
    @IBOutlet var txtNameSecond: UITextField!
    
    var delegate:ProtocolSecondVCDelegate?
    
    var name :String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtNameSecond.text = name
    }

    @IBAction func btnSavePressed(_ sender: Any) {
        //FIXME: OPTIONAL
        
        if let delegate = self.delegate, let text = txtNameSecond.text {
            delegate.saveWasPerformed(editedText: text)
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func btnGoToThirdVCPressed(_ sender: Any) {
        
        let thirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        self.navigationController?.pushViewController(thirdVC, animated: true)
    }
    
}
