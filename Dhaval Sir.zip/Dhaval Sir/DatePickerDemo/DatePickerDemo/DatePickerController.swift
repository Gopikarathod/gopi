//
//  DatePickerController.swift
//  DatePickerDemo
//
//  Created by agile on 19/09/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class DatePickerController: UIDatePicker {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
