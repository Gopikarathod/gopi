 //  ViewController.swift
//  DatePickerDemo

//  Created by agile on 17/09/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

 class: UIViewController{
    weak var Label: UILabel!
          
    weak var TextField: UITextField!
   
   
    var datePicker:UIDatePicker!
   
    func viewDidLoad() {
 super.viewDidLoad()
       
    // create a datepicker
    let DatePicker: UIDatePicker = UIDatePicker()
       
    // postion date picker within a view
    DatePicker.frame = CGRect(x: 10, y: 50, width:Self.view.frame.width, height: 200)
      
   //set some of UIdatepicker properties
    DatePicker.timeZone=NSTimeZone.local
    DatePicker.backgroundColor = UIColor.white
    //Add an event to call ondidchangeddate function when value is changed.
        DatePicker.addTarget(self, action: #selector(ViewController.datePickerValueChanged(_sender(_:)),for: datePicker(_sender:DatePicker))
   
    func datePickerValueChanged(_sender:UIDatePicker){
//apply date Format
        let selectedDate:String = dateFormatter.String(from:_sender.date)
        func

            didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
        }
}

