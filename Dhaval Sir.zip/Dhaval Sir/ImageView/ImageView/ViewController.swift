//
//  ViewController.swift
//  ImageView
//
//  Created by agile on 04/10/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

//image UIImage = UIImage(named: "universal-logo")!
//var imageView = UIImageView(image: image)



class ViewController: UIViewController {
    
    
    @IBOutlet var imageView: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
  
        
        let image1: UIImage = UIImage(named: "universal-logo")!
        
        
        imageView.image = image1
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

