//
//  ViewController.swift
//  Gesture_TEST
//
//  Created by agile-2 on 03/10/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var swipeGesture: UISwipeGestureRecognizer!
    
    @IBOutlet weak var viewForTap: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()



//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.gestureHandler(sender:)))
////        tapGesture.numberOfTouchesRequired = 2
////        tapGesture.numberOfTapsRequired = 2
//        viewForTap.addGestureRecognizer(tapGesture)
//
//
//        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(self.pinchGestureHandler(sender:)))
//        viewForTap.addGestureRecognizer(pinchGesture)
        
        
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(self.panGestureHandler(sender:)))
        viewForTap.addGestureRecognizer(panGesture)

        
        swipeGesture.direction = .left
        viewForTap.addGestureRecognizer(swipeGesture)
        
        panGesture.require(toFail: swipeGesture)
        
    }
    
    @IBAction func swipeGestureHander(_ sender: UISwipeGestureRecognizer) {
        print("SWIPE HANDLER CALLED..")

    }
    @objc private func gestureHandler(sender:UIGestureRecognizer) {
        print("GESTURE HANDLER CALLED..")
    }

    @objc private func pinchGestureHandler(sender:UIGestureRecognizer) {
//        print("PINCH GESTURE HANDLER CALLED..")
        
        
        switch sender.state {
        case .began:
            print("BEGAN")
        case .changed:
            print("CHANGED")
        case .ended:
            print("ENDED")
        case .cancelled:
            print("CANCELLED")
        case .failed:
            print("FAILED")
        case .possible:
            print("POSSIBLE")
        }
    }

    @objc private func panGestureHandler(sender:UIGestureRecognizer) {
        //        print("PINCH GESTURE HANDLER CALLED..")
        
        
        switch sender.state {
        case .began:
            print("PAN BEGAN")
        case .changed:
            print("CHANGED")
        case .ended:
            print("ENDED")
        case .cancelled:
            print("CANCELLED")
        case .failed:
            print("FAILED")
        case .possible:
            print("POSSIBLE")
        }
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

