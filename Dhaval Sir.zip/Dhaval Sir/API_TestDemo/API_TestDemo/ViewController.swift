//
//  ViewController.swift
//  API_TestDemo
//
//  Created by agile on 11/10/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let dict:[String:Any] = ["key1" : "value1",
                            "key2" : "value2",
                            "key3" : "value3"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
   
        if  let  path = Bundle .main.path(forResource: "jsonTestFile_1", ofType: "json")
        {
               let realPath = URL(fileURLWithPath: path)
                do {
               
                    let jsonData = try Data(contentsOf: realPath, options: Data.ReadingOptions.mappedIfSafe)

                     let jsonResult = try  JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions.allowFragments)
                
                print(jsonResult)
                
                if let arr = jsonResult as? NSArray{
                    
                    for i in 0..<arr.count {

                        if let SecondDict = arr[i] as? NSDictionary{
                            switch i {
                            
                                  case 0 :
                                     if let Name =
                                       SecondDict["display"]{
                                       print(Name)
                                      }
                                 case 1:
                                    if let name = SecondDict["display1"] {
                                      print(name)
                                      }
                                  case 2:
                                    if let name = SecondDict["display2"] {
                                       print(name)
                                       }
                            default:
                                break
 
                            }
                            
                        }
                }
               
                }
            }catch{
                print(error.localizedDescription)
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

