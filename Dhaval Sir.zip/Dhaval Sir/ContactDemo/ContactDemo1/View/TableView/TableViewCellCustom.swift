//
//  TableViewCellCustom.swift
//  ContactDemo1
//
//  Created by agile on 22/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class TableViewCellCustom: UITableViewCell {

    @IBOutlet var lblNameTableViewCellCustom: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
