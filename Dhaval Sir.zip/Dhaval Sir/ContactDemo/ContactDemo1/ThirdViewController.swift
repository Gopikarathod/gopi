//
//  ThirdViewController.swift
//  ContactDemo1
//
//  Created by agile on 22/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    //MARK:- PROPERTIES
    @IBOutlet var txtNameThirdVC: UITextField!
    @IBOutlet var txtNumberThirdVC: UITextField!
    

//    var dictEmployeeToReceive:[String:Any] = [:]
    var modelEmployeeToReceive:ModelEmployee = ModelEmployee()

    
      //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
      
//        self.txtNameThirdVC.text = dictEmployeeToReceive["name"] as! String
//
//        let intId = dictEmployeeToReceive["id"] as! Int
//        let strId = "\(intId)"
//
//        self.txtNumberThirdVC.text = strId

        
        self.txtNameThirdVC.text = self.modelEmployeeToReceive.firstName
        
        let intId = modelEmployeeToReceive.id
        let strId = "\(intId)"
        
        self.txtNumberThirdVC.text = strId

        
        
        
    }
    
    

   
}
