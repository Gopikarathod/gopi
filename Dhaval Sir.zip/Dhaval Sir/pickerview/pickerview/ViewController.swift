//
//  ViewController.swift
//  PickerView
//
//  Created by agile on 21/09/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var Label: UILabel!
    
    @IBOutlet weak var pickerView: UIPickerView!
    
    
    @IBOutlet weak var datePickerView: UIDatePicker!
    
    
var arrPickerItem = [String]()
    
    override func viewDidLoad(){
        super.viewDidLoad()
        doSetupUI()
    }
    
    func doSetupUI() {
        
        for i in 0..<15 {
            arrPickerItem.append("Picker Item \(i)")
        }
        
        pickerView.dataSource = self
        pickerView.delegate = self
        
        // ACTION
        
        datePickerView.addTarget(self, action: #selector(self.dateValueChangeHandler(datePicker1:)), for: UIControlEvents.valueChanged)
        
    }
    
    
    @objc func dateValueChangeHandler(datePicker1:UIDatePicker) {
        
        DispatchQueue.main.async {
            print("DATE CHANGED : \(datePicker1.date)")
            
            self.Label.text = "\(datePicker1.date)"
        }
        
    }
    
    
    
    
}

extension ViewController : UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrPickerItem.count
    }
}

extension ViewController : UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrPickerItem[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        print("Did Select Row : \(row) in Component : \(component)")
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        view.backgroundColor = .red
        
        return view
    }
    
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 50
    }
    
}

