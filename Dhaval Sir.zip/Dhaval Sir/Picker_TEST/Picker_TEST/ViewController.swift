//
//  ViewController.swift
//  Picker_TEST
//
//  Created by agile-2 on 14/09/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var pickerTest: UIPickerView!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    
    var arrPickerItems = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        doSetupUI()
    }

    func doSetupUI() {
        
        for i in 0..<15 {
            arrPickerItems.append("Picker Item \(i)")
        }
        
        pickerTest.dataSource = self
        pickerTest.delegate = self
        
        // ACTION
        
        datePicker.addTarget(self, action: #selector(self.dateValueChangeHandler(datePicker1:)), for: UIControl.Event.valueChanged)
        
    }

    
    @objc func dateValueChangeHandler(datePicker1:UIDatePicker) {
        
        DispatchQueue.main.async {
            print("DATE CHANGED : \(datePicker1.date)")
            
            self.lblDate.text = "\(datePicker1.date)"
        }
        
    }
    
   
    
    
}

extension ViewController : UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrPickerItems.count
    }
}

extension ViewController : UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrPickerItems[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        print("Did Select Row : \(row) in Component : \(component)")
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        view.backgroundColor = .red
        
        return view
    }
    
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 50
    }
    
}

