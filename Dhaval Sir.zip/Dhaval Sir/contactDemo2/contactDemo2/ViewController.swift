//
//  ViewController.swift
//  contactDemo2
//
//  Created by agile on 09/10/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

//struct ModelEmployee {
//    var firstName:String
//    var lastName:String
//    var id:Int
//
//    init() {
//        self.firstName = ""
//        self.lastName = ""
//        self.id = 0
//    }
//}

class ModelEmployee: NSObject {
    //    var firstName:String = ""
    //    var lastName:String = ""
    //    var id:Int = 0
    
    var firstName:String
    var lastName:String
    var id:Int
    
    override init() {
        
        self.firstName = ""
        self.lastName = ""
        self.id = 0
    }
    
    init(firstName:String,lastName:String,id:Int) {
        
        self.firstName = firstName
        self.lastName = lastName
        self.id = id
    }
    
    
}

class ViewController: UIViewController {
    
    //MARK:- PROPERTIES
    
    @IBOutlet var txtNameFirstVC: UITextField!
    
    @IBOutlet var txtNumberFirstVC: UITextField!
    
    //    var dictEmployee:[String:Any] = [:]
    //    var modelEmployee:ModelEmployee = ModelEmployee()
    
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
        doSetupUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if !txtNameFirstVC.isFirstResponder {
            txtNameFirstVC.becomeFirstResponder()
        }
    }
    
    
    private func doSetupUI() {
        txtNumberFirstVC.keyboardType = .numberPad
        
        
    }
    
    //MARK:- BUTTON ACTION
    @IBAction func btnSendToSecondVC(_ sender: Any) {
        
        let strId = txtNumberFirstVC.text!
        let intId = Int(strId)
        
        guard let intIdFinal = intId else {
            return
        }
        
        //        dictEmployee["id"] = intIdFinal
        //        dictEmployee["name"] = txtNameFirstVC.text!
        
        let modelEmployee:ModelEmployee = ModelEmployee()
        
        modelEmployee.firstName = txtNameFirstVC.text!
        modelEmployee.id = intIdFinal
        
        
        //        appDelegate.arrGlobalData.append(dictEmployee)
        appDelegate.arrGlobalEmployees.append(modelEmployee)
        
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! TableViewCellCustom
        
        guard let navigationController = self.navigationController else {
            return
        }
        navigationController.pushViewController(secondVC, animated: true)
        
        txtNameFirstVC.text = ""
        txtNumberFirstVC.text = ""
        
    }
}




//class ViewController: UIViewController {
//
//    //MARK:- PROPERTIES
//
//    @IBOutlet var txtNameFirstVC: UITextField!
//    @IBOutlet var txtNumberFirstVC: UITextField!
//
//    var model1 = Model()
//    var model2 = Model()
//    var model3 = Model()
//
//
//    //MARK:- VIEW LIFE CYCLE
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        model1.name = "first"
//        model2.name = "second"
//
//        print("First : \(model1.name)")
//        print("Second : \(model2.name)")
//
//        model3 = model2
//
//        print("Third : \(model3.name)")
//
//        model3.name = "XXXXXXx"
//
//        print("Third Updated : \(model3.name)")
//
//        print("Second : \(model2.name)")
//    }
//
//
//    //MARK:- BUTTON ACTION
//    @IBAction func btnSendToSecondVC(_ sender: Any) {
//        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
//
//        guard let navigationController = self.navigationController else {
//            return
//        }
//
//        secondVC.arrRows = [txtNameFirstVC.text!]
//
//        navigationController.pushViewController(secondVC, animated: true)
//
//    }
//}


