//
//  ThirdViewController.swift
//  contactDemo2
//
//  Created by agile on 09/10/18.
//  Copyright © 2018 agile. All rights reserved.
//


import UIKit

protocol ThirdViewControllerDelegate {
    
    func saveWasPerformed()
}

class ThirdViewController: UIViewController {
    
    //MARK:- PROPERTIES
    @IBOutlet var txtNameThirdVC: UITextField!
    @IBOutlet var txtNumberThirdVC: UITextField!
    
    var delegate:ThirdViewControllerDelegate?
    
    
    //    var dictEmployeeToReceive:[String:Any] = [:]
    var modelEmployeeToReceive:ModelEmployee = ModelEmployee()
    
    
    var blockSaveWasPerformed:( (_ name:String,_ id:Int) -> Void )?
    
    func test(arg:Int) -> String {
        return ""
    }
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //        self.txtNameThirdVC.text = dictEmployeeToReceive["name"] as! String
        //
        //        let intId = dictEmployeeToReceive["id"] as! Int
        //        let strId = "\(intId)"
        //
        //        self.txtNumberThirdVC.text = strId
        
        
        self.txtNameThirdVC.text = self.modelEmployeeToReceive.firstName
        
        let intId = modelEmployeeToReceive.id
        let strId = "\(intId)"
        
        self.txtNumberThirdVC.text = strId
    }
    
    
    
    
    @IBAction func saveBtnPressed(_ sender: Any) {
        
        
        let strId = txtNumberThirdVC.text!
        let intId = Int(strId)
        
        guard let intIdFinal = intId else {
            return
        }
        
        if self.blockSaveWasPerformed != nil {
            self.blockSaveWasPerformed!(txtNameThirdVC.text!, intIdFinal)
        }
        
        
        //        modelEmployeeToReceive.firstName = txtNameThirdVC.text!
        //        modelEmployeeToReceive.id = intIdFinal
        //
        //        self.delegate?.saveWasPerformed()
        
        _ = self.navigationController?.popViewController(animated: true)
    }
}


