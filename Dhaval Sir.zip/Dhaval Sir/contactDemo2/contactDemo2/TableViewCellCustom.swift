//
//  TableViewCellCustom.swift
//  contactDemo2
//
//  Created by agile on 09/10/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class TableViewCellCustom: UITableViewCell {

    //MARK:- PROPERTIES
    @IBOutlet var tableViewSecondVC: UITableView!
    
    //MARK:- VIEW LIFE CYCLE
    
      override func viewDidLoad() {
         super.viewDidLoad()
        doSetUpUI()
        doSetUpData()
    }
    
    private func doSetUpUI(){
        tableViewSecondVC.dataSource = self
        tableViewSecondVC.delegate = self
        
        let nibName = UINib(nibName: "TableViewCellCustom", bundle: nil)
        tableViewSecondVC.register(nibName, forCellReuseIdentifier: "Cell")
        
        
        // TITLE
       // self.navigationItem.title = "table test"
        
        
        // BAR BUTTON ITEM
        
        //        let leftBarButtonItem = UIBarButtonItem(title: "TEST", style: UIBarButtonItemStyle.plain, target: self, action: nil)
        
        
        _ = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.add, target: self, action: #selector(self.tabBarButton1))
        
        
        
        //self.navigationItem.rightBarButtonItems = [leftBarButtonItemBookmark]
        
        
        
    }
    
    @objc func tabBarButton1(){
        print("Bar Button Pressed")
    }
    
    private func doSetUpData(){
        //        for i in 0 ..< 10{
        //            arrRows.append("\(i)")
        //        }
        
        
    }
    
    
    
    //    @IBAction func barButtonInsertRow(_ sender: UIBarButtonItem) {
    //
    //        let newRowToBeInserted = "NEW ROW"
    //        let indexToInsertAt = 0
    //
    //        arrRows.insert(newRowToBeInserted, at: indexToInsertAt)
    //
    //        let indexPathToInsertAt = IndexPath(row: indexToInsertAt, section: 0)
    //
    //        tableViewSecondVC.insertRows(at: [indexPathToInsertAt], with: UITableViewRowAnimation.right)
    //
    //    }
    
    
    
}

//MARK:- EXTENTION UITableViewDataSource
extension TableViewCellCustom : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  appDelegate.arrGlobalEmployees.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
        
        _ = appDelegate.arrGlobalEmployees[indexPath.row]
        
        //        cell.lblNameTableViewCellCustom.text = dictData["name"] as! String
        return cell
    }
    
    
}

//MARK:- EXTENTION UITableViewDelegate
extension TableViewCellCustom : UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let thirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
        
        //        thirdVC.dictEmployeeToReceive = appDelegate.arrGlobalData[indexPath.row]
        
        thirdVC.modelEmployeeToReceive = appDelegate.arrGlobalEmployees[indexPath.row]
        //        thirdVC.delegate = self
        
        thirdVC.blockSaveWasPerformed = { (name,id) in
            print("Save was performed : Name : \(name),Id:\(id)")
        }
        
        navigationController.pushViewController(thirdVC, animated: true)
        print("This is \(indexPath.row) Row")
    }
    
    //    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
    //        if editingStyle == .insert{
    //
    //            if indexPath.row == nil{
    //
    //                let newRowToBeInserted = "NEW ROW"
    //                let indexToInsertAt = 0
    //
    //                arrRows.insert(newRowToBeInserted, at: indexToInsertAt)
    //
    //                let indexPathToInsertAt = IndexPath(row: indexToInsertAt, section: 0)
    //
    //                tableViewSecondVC.insertRows(at: [indexPathToInsertAt], with: UITableViewRowAnimation.right)
    //
    //
    //            }else {
    //                print("Row can not be inserted")
    //            }
    //
    //
    //        }
    //    }
}

extension TableViewCellCustom : ThirdViewControllerDelegate {
    func saveWasPerformed() {
        print("Save method was called in third vc")
        let aa = appDelegate.arrGlobalEmployees
        print(aa)
        
        tableViewSecondVC.reloadData()
    }
}

