//
//  ViewController.swift
//  datepickerview
//
//  Created by agile-10 on 14/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

struct statedata {
    var state:String
    var city:[String] = []
}

struct countrydata {
    var country:String
    var state:[statedata] = []
}

var pickerdat :[countrydata] = []

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate{
  
    
    
    @IBOutlet var datepickerview:UIDatePicker!
    @IBOutlet var pickerview:UIPickerView!
    @IBOutlet var myview:UIView!
    @IBOutlet var txtbdate:UITextField!
    @IBOutlet var txtcountry:UITextField!
    @IBOutlet var txtstate:UITextField!
    @IBOutlet var txtcity:UITextField!
    @IBOutlet var lbldiff:UILabel!
     var cnt:Int = 0
     var stat:Int = 0
     var city:Int = 0
   

    override func viewDidLoad() {
        super.viewDidLoad()
        self.datepickerview.isHidden = true
        self.pickerview.isHidden = true
        self.pickerview.dataSource = self
        self.pickerview.delegate = self
        self.txtbdate.delegate = self
        self.txtcountry.delegate = self
        self.txtstate.delegate = self
        self.txtcity.delegate = self
        self.datepickerview.minimumDate = Date()
        
        var st = countrydata(country:"UK",state:[statedata(state:"aaaa",city:["a","b","c"])])
        st.state.append(statedata(state:"bbbb",city:["d","e"]))
        pickerdat.append(st)
        
        st = countrydata(country:"India",state:[statedata(state:"gujrat",city:["aa","ba","ca"])])
        st.state.append(statedata(state:"mp",city:["ad","ae"]))
        pickerdat.append(st)
    
     /*   txtbdate.inputView = UIDatePicker()
        txtcountry.inputView = UIPickerView()
        txtstate.inputView = UIPickerView()
        txtcity.inputView = UIPickerView()*/
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (component == 0){
            return pickerdat.count
        }else if(component == 1){
            return pickerdat[cnt].state.count
        }else if(component == 2){
            return pickerdat[cnt].state[stat].city.count
        }
      return 0
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if (component == 0){
            return pickerdat[row].country
        }else if(component == 1){
            return pickerdat[cnt].state[row].state
        }else if(component == 2){
            return pickerdat[cnt].state[stat].city[row]
        }
        
        return ""
    }
   
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if (textField == txtbdate){
            self.datepickerview.isHidden = false
            self.pickerview.isHidden = true
        }else if(textField == txtcity) || (textField == txtstate) || (textField == txtcountry){
            self.datepickerview.isHidden = true
            self.pickerview.isHidden = false
        }
        
        return true
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (component == 0){
        cnt = pickerView.selectedRow(inComponent: 0)
        stat = 0
        city = 0
        pickerView.reloadComponent(1)
        pickerView.selectRow(0, inComponent: 1, animated: true)
        pickerView.reloadComponent(2)
        pickerView.selectRow(0, inComponent: 2, animated: true)
        
        }else if (component == 1){
            stat = pickerView.selectedRow(inComponent: 1)
            city = 0
            
            pickerView.reloadComponent(2)
            pickerView.selectRow(0, inComponent: 2, animated: true)
        }else if(component == 2){
            city = pickerView.selectedRow(inComponent: 2)
        }
    }
    
    @IBAction func btnprint(){
    
//            txtcountry.text = country
//          lbldiff.text = "\(bdate)"
      //  let dateFormatter1:DateFormatter = DateFormatter()
       // dateFormatter1.dateFormat = "MM-dd-yyyy"
       // let newdate:Date = dateFormatter1.date(from: bdate)!
      //  let stringdate:String = dateFormatter1.string(from: date)
       // var diff = date.compare(newdate).rawValue
      //  var year = ((date) - (newdate))
        //let cal = Calendar.current.component(Calendar.Component.month, from:newdate)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

