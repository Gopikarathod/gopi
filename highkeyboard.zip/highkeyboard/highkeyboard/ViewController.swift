//
//  ViewController.swift
//  highkeyboard
//
//  Created by agile-10 on 03/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import TPKeyboardAvoiding


class ViewController: UIViewController,UITextFieldDelegate{
    
      @IBOutlet var scroll:TPKeyboardAvoidingScrollView!
      @IBOutlet var scrolview:UIView!
      @IBOutlet var txt1:UITextField!
      @IBOutlet var txt2:UITextField!
      @IBOutlet var txt3:UITextField!
      @IBOutlet var txt4:UITextField!
      @IBOutlet var txt5:UITextField!
      @IBOutlet var txt6:UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    

  
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

