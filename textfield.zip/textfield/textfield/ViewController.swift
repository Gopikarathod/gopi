//
//  ViewController.swift
//  textfield
//
//  Created by agile on 07/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit


class ViewController: UIViewController,UITextFieldDelegate {
    
    var data:[[String:Any]] = []
    
    @IBOutlet var id:UITextField!
    @IBOutlet var name:UITextField!
    @IBOutlet var number:UITextField!
  
   
    var add:UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        id = UITextField.init(frame: CGRect.init(x: 120, y: 100, width: 200, height: 50))
       
        id.borderStyle = .bezel
        id.isEnabled = false
        id.text = "\(data.count+1)"
        self.view.addSubview(id)
        
        name = UITextField.init(frame: CGRect.init(x: 120, y: 200, width: 200, height: 50))
        
        name.borderStyle = .bezel
        name.placeholder = "Name"
        name.delegate = self
        name.keyboardType = .default
        self.view.addSubview(name)
        
        number = UITextField.init(frame: CGRect.init(x: 120, y: 300, width: 200, height: 50))
        number.delegate = self
        number.borderStyle = .bezel
        number.placeholder = "Number"
        number.keyboardType = .numberPad
        self.view.addSubview(number)
    
        
        add = UIButton.init(frame: CGRect.init(x: 120, y: 400, width: 200, height: 50))
        add.addTarget(self, action:#selector(buttonadd), for: UIControlEvents.touchUpInside)
        add.setTitle("Add", for: UIControlState.normal)
        add.backgroundColor = UIColor.blue
       
        self.view.addSubview(add)
       mainload()
    
        // Do any additional setup after loading the view, typically from a nib.
    }
    func mainload() {
       
        add.isEnabled = false
        id.text = "\(data.count+1)"
        name.text = ""
        number.text = ""
        name.becomeFirstResponder()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if (textField == name){
            if ((name.text?.count)! >= 4 && (name.text?.count)! <= 50){
                return true
            }
            else {
                print("enter name correct")
            }
        }
        else if(textField == number)
        {
            name.becomeFirstResponder()
           
        }
    
        return false
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if(textField == name){
            for i in 0...9 { // not entered 0 to 9 digit
                if(string == "\(i)")
                {
                return false
                }
            }
            
        }
        
        if (textField == number){
         
                    if (((number.text?.count)!+1) >= 8 && ((number.text?.count)!+1) <= 12){
                        add.isEnabled = true
                
                }
            
            else {
                print("enter number correct")
                    
                }
        }
        return true
    }
    
    @objc func buttonadd() {
        
        let info:[String:Any]=["name":name.text!,"number":number.text!,"id":data.count+1]
        data.append(info)
        print(data)
      
        mainload()
        
        
    }


}

