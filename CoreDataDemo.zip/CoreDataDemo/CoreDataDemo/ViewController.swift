//
//  ViewController.swift
//  CoreDataDemo
//
//  Created by agilemac-24 on 5/14/18.
//  Copyright © 2018 agilemac-24. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.insertDataInCoreDatabase()
        //self.updateRecord()
       // self.fetchRecord()
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func insertDataInCoreDatabase(){
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
       
        let manageContext = appDelegate.persistentContainer.viewContext
        let entity:NSEntityDescription = NSEntityDescription.entity(forEntityName: "UserList", in: manageContext)!
        let object:NSManagedObject = NSManagedObject.init(entity: entity, insertInto: manageContext)
        object.setValue(10, forKey: "id")
        object.setValue("Urvish", forKey: "name")
        do{
            try manageContext.save()
            
        }catch{
            
        }
        
        
        
    }

    func fetchRecord(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        
        let manageContext = appDelegate.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest =          NSFetchRequest<NSManagedObject>.init(entityName: "UserList")
        //fetchRequest.predicate
        //fetchRequest.sortDescriptors
        do{
            var aryUSers:[[String:Any]] = []
           
            let data = try manageContext.fetch(fetchRequest)
            for user in data {
                
                //try manageContext.delete(user)
                
                var dict:[String:Any] = [:]
                dict["id"] = user.value(forKey: "id") as? Int
                dict["name"] = user.value(forKey: "name") as? String
                aryUSers.append(dict)
                
                print(user.value(forKey: "id") as Any)
            }
            
        }catch {
            
        }
        
    }
    func updateStudentName(withName name:String,withStudentID id:Int){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        
        let manageContext = appDelegate.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest =          NSFetchRequest<NSManagedObject>.init(entityName: "UserList")
        fetchRequest.predicate = NSPredicate.init(format: "id = %@", id)
        
        do{
            let data = try manageContext.fetch(fetchRequest)
            for user in data {
                //user.setValue(13, forKey: "id")
                user.setValue(name, forKey: "name")
            }
            
            try manageContext.save()
        }catch {
            
        }
    }
    func updateRecord() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        
        let manageContext = appDelegate.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest =          NSFetchRequest<NSManagedObject>.init(entityName: "UserList")
        
        do{
            let data = try manageContext.fetch(fetchRequest)
            for user in data {
                user.setValue(13, forKey: "id")
                
            }
            
            
        }catch {
            
        }
        
        
    }
}

