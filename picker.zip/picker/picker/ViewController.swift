//
//  ViewController.swift
//  picker
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource{
    
    
    
    @IBOutlet var lblname:UILabel!
    @IBOutlet var mypicker:UIPickerView!
    @IBOutlet var myview:UIView!
    

    
    var arrpicker:[String:Any] = ["gopika":1,"raghika":2,"rachna":3,"nirali":4,"krupali":5]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.mypicker.dataSource = self
        self.mypicker.delegate = self
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrpicker.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        //var arr = arrpicker.count
         if (component == 0){
            for (key,_) in arrpicker {
                
                return key
            }
            
        }
       // return arrpicker[row]
        return "1"
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
       // return lblname.text =  arrpicker[row]
        if (component == 0){
            for (_,value) in arrpicker{
                if (component == 1){
                    let i:String = (value as? String)!
                    print(i)
                }
            }
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

