//
//  ViewController.swift
//  studCoredata
//
//  Created by agile-10 on 15/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet var txtId:UITextField!
    @IBOutlet var txtName:UITextField!
    @IBOutlet var txtCity:UITextField!
    @IBOutlet var txtNumber:UITextField!
    
    var studDict:[String:Any] = [:]


    override func viewDidLoad() {
        super.viewDidLoad()
        txtId.isEnabled = false
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
         // deleteRecordInDAtabuse()

        fetchDataInDatabuse()

        let objapp = UIApplication.shared.delegate as? AppDelegate
        txtId.text = "\((objapp?.arrstud.count)! + 1)"
    }
    
    func deleteRecordInDAtabase(){
        
        guard  let objapp = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managecontext = objapp.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Student")
        
        do{
            let data = try managecontext.fetch(fetchRequest)
            
            for user in data {
                try managecontext.delete(user)
                try managecontext.save()
                print(objapp.arrstud)
            }
            
        } catch{
            print(error.localizedDescription)
        }
        
    }
    
    func fetchDataInDatabuse(){
        
        guard  let objapp = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managecontext = objapp.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Student")
        
        do{
            let data = try managecontext.fetch(fetchRequest)
            
            for user in data {
                
                studDict["id"] = user.value(forKey: "id")
                studDict["name"] = user.value(forKey: "name")
                studDict["city"] = user.value(forKey: "city")
                studDict["number"] = user.value(forKey: "number")
                
             //   print(studDict["id"])
                
                objapp.arrstud.append(studDict)
                print(objapp.arrstud)
                
            }
        
        } catch{
            print(error.localizedDescription)
        }
    }
    
    func insertDataInCoreDatabase(){
        
        
        
    //    print(studDict["id"])
        
        guard let objapp = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        
        studDict = ["id":txtId.text ?? "","name":txtName.text ?? "","city":txtCity.text ?? "","number":txtNumber.text ?? "" ]
        
         let manageContext = objapp.persistentContainer.viewContext
    
        let Entity:NSEntityDescription = NSEntityDescription.entity(forEntityName: "Student", in: manageContext)!
        let attribute:NSManagedObject = NSManagedObject.init(entity: Entity, insertInto: manageContext)
        
        attribute.setValue(studDict["id"], forKey: "id")
        attribute.setValue(studDict["name"], forKey: "name")
        attribute.setValue(studDict["city"], forKey: "city")
        attribute.setValue(studDict["number"], forKey: "number")
        do{
            try manageContext.save()
            print("save data")
        }
        catch{
            print(error.localizedDescription)
        }
    }
    
    @IBAction func btnSave(){

        insertDataInCoreDatabase()
        
        txtId.text = ""
        txtName.text = ""
        txtCity.text = ""
        txtNumber.text = ""
        
        txtName.becomeFirstResponder()
        
        let objnamevc:NameViewController = (storyboard?.instantiateViewController(withIdentifier: "NameViewController") as? NameViewController)!
        
        self.navigationController?.pushViewController(objnamevc, animated: true)
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

