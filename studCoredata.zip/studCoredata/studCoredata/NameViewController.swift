//
//  NameViewController.swift
//  studCoredata
//
//  Created by agile-10 on 15/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class NameViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource{
    
    
    @IBOutlet var tblname:UITableView!
    
    let objapp = UIApplication.shared.delegate as? AppDelegate

    override func viewDidLoad() {
        super.viewDidLoad()
        tblname.delegate = self
        tblname.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(objapp?.arrstud)
        return (objapp?.arrstud.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:NameTableViewCell = (tableView.dequeueReusableCell(withIdentifier: "NameTableViewCell") as? NameTableViewCell)!
        
        let objname = objapp?.arrstud[indexPath.row]
        
        cell.lblname.text = objname?["name"] as? String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let objselect = objapp?.arrstud[indexPath.row]
        //print(obj)
        let objdetailvc:DetailViewController = (storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController)!
        objdetailvc.id = (objselect?["id"] as? String)!
        objdetailvc.name = (objselect?["name"] as? String)!
        objdetailvc.city = (objselect?["city"] as? String)!
        objdetailvc.number = (objselect?["number"] as? String)!
        
        self.navigationController?.pushViewController(objdetailvc, animated: true)

    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
