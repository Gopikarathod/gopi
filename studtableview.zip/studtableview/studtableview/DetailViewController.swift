//
//  DetailViewController.swift
//  studtableview
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 AshishSalet. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    @IBOutlet var lblid:UILabel!
    @IBOutlet var lblname:UILabel!
    @IBOutlet var lblnumber:UILabel!
    @IBOutlet var lblcity:UILabel!
    var id = ""
    var name = ""
    var number = ""
    var city = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
            lblid.text = id
            lblname.text = name
            lblnumber.text = number
            lblcity.text = city
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
