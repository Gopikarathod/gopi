//
//  stdtblViewController.swift
//  studtableview
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 AshishSalet. All rights reserved.
//

import UIKit

class stdtblViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
  
    
    var info:[[String:String]] = []
    
    @IBOutlet var objtble: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        
        self.objtble.dataSource = self
        self.objtble.delegate = self
        
      
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return info.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        if let cell:studTableViewCell = tableView.dequeueReusableCell(withIdentifier: "studTableViewCell") as?  studTableViewCell {
            
            let objinfo:[String:String] = self.info[indexPath.row]
            
            cell.lblid.text = objinfo["id"]
            cell.lblname.text = objinfo["name"]
            cell.lblnumber.text  = objinfo["number"]
            cell.lblcity.text = objinfo["city"]
            return cell
        
        }
   
    return UITableViewCell.init(style: .default, reuseIdentifier: "cell")
   
}
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
