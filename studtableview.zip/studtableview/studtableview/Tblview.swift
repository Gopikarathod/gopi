//
//  Tblview.swift
//  studtableview
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 AshishSalet. All rights reserved.
//

import UIKit

class Tblview: UIViewController ,UITableViewDelegate,UITableViewDataSource{
    
    
    
  
    
    var tblinfo:[[String:Any]] = []

    
    @IBOutlet var tblstud: UITableView!
    
   
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let objview = ViewController()
        tblinfo = objview.stddic
        
        self.tblstud.delegate = self
        self.tblstud.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tblinfo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "tableCell"){
            return cell
        }
        return UITableViewCell.init(style: .default, reuseIdentifier: "cell")
       
    }
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
