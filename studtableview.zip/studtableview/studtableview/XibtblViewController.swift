//
//  XibtblViewController.swift
//  studtableview
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 AshishSalet. All rights reserved.
//

import UIKit

class XibtblViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
   
    @IBOutlet var xibtbl:UITableView!
    
    var xibarr:[[String:String]] = []
    //var name:[String] = []


    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.xibtbl.dataSource = self
        self.xibtbl.delegate = self
        
        
      
        self.xibtbl.register(UINib.init(nibName: "ViewCell", bundle: nil), forCellReuseIdentifier: "ViewCellIdentifier")

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return xibarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell:ViewCell = tableView.dequeueReusableCell(withIdentifier: "ViewCellIdentifier") as? ViewCell{
            
            
            var data:[String:String]=self.xibarr[indexPath.row]
            cell.lblname.text! = data["name"]!
           // cell.img.backgroundColor = UIColor.red
            
            return cell
        }
        return UITableViewCell.init(style: .default, reuseIdentifier: "cell")
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let objdetail:DetailViewController = (storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController)!
        
        var info:[String:String] = xibarr[indexPath.row]
        
        objdetail.id = info["id"]!
        objdetail.name = info["name"]!
        objdetail.number = info["number"]!
        objdetail.city = info["city"]!
        
        self.navigationController?.pushViewController(objdetail, animated: true)
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
