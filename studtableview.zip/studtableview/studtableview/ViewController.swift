//
//  ViewController.swift
//  student_dist
//
//  Created by agile-02 on 19/07/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    @IBOutlet    var stdid:UITextField!
    @IBOutlet     var stdname:UITextField!
    @IBOutlet     var stdnumber:UITextField!
    @IBOutlet     var stdcity:UITextField!
   
    
    
    
    
    var stddic:[[String:String]] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.stud(withname: "gopi", withnumber:"8962355544",withcity: "botad")
        self.stud(withname: "radhi", withnumber:"6325874199",withcity: "abad")
        self.stud(withname: "dipee", withnumber:"7896541239",withcity: "bhavnager")
        print(stddic)
        stddisplay()
        
  
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    /// <#Description#>
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    
    
    func stud(withname name:String,withnumber number:String,withcity city:String){
        let studdata:[String:String] =  ["name":name,"number":number,"city":city,"id":"\(stddic.count+1)"]
        
        stddic.append(studdata)
       
        
    }
 
   
    func stddisplay() {
      
        stdid.text = "\(stddic.count+1)"
        stdname.text = ""
        stdnumber.text = ""
        stdcity.text = ""
        stdname.becomeFirstResponder()
    }
    
    
        @IBAction func nextclick(_ sender: Any) {
        
            
            let info:[String:String] = ["id":"\(stddic.count+1)","name":stdname.text!,"number":stdnumber.text!,"city":stdcity.text!]
            
            stddic.append(info)
            stddisplay()
           
            print(info)
       /*   if let objstdtbl:stdtblViewController = storyboard?.instantiateViewController(withIdentifier: "stdtblViewController") as? stdtblViewController {
                objstdtbl.info=stddic
                self.navigationController?.pushViewController(objstdtbl, animated: true)*/
            if let xibobj:XibtblViewController = storyboard?.instantiateViewController(withIdentifier: "XibtblViewController") as? XibtblViewController {
                
                xibobj.xibarr = stddic
                self.navigationController?.pushViewController(xibobj, animated: true)
            }
            
          
         //   }
        
         
    
    }
}
