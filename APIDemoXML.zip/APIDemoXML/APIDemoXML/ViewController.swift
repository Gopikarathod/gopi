//
//  ViewController.swift
//  APIDemoXML
//
//  Created by agile-10 on 23/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,XMLParserDelegate{
    
    var objparser:XMLParser!
    var arrBreckfast:[[String:Any]] = []
    var dict:[String:Any] = [:]
    var strElement:String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let pathXML = Bundle.main.path(forResource: "simple", ofType: "xml")
        objparser = XMLParser.init(contentsOf: URL.init(fileURLWithPath: pathXML!))
        objparser.delegate = self
        objparser.parse()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        strElement = elementName
        
        if elementName == "food"{
            dict = [:]
        }
        
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "food"{
            arrBreckfast.append(dict)
        }

    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        var str:String = string
        str = str.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        
        if strElement != "food"{
            dict[strElement] = str
            strElement = ""
        }
    }
    
    func parserDidEndDocument(_ parser: XMLParser) {
        print(arrBreckfast)
    }

}

