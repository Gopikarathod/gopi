//
//  ViewController.swift
//  DemoXMLParser
//
//  Created by agilemac-24 on 1/17/18.
//  Copyright © 2018 agilemac-24. All rights reserved.
//




import UIKit

class ViewController: UIViewController,XMLParserDelegate {

    var objParse:XMLParser!
    
    var dictData:[String:Any] = [:]{
        didSet{
            print(dictData)
        }
    }
    var arrAllData:[[String:Any]] = []
    var strElement:String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let strPath:String = Bundle.main.path(forResource: "simple", ofType: "xml")!
        objParse = XMLParser.init(contentsOf: URL.init(fileURLWithPath: strPath))
        objParse.delegate = self
        objParse.parse()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        strElement=elementName;
        if elementName == "food"
        {
            
            //dictData = [:];
            return;
            
        }
        
        
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if elementName == "food"
        {
           arrAllData.append(dictData)
        }
        
    }
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
        var strString = string
        strString = strString.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        print(strString)
        if strElement == "name"
        {
            dictData[strElement] = strString
            strElement = ""
        }
        
    }
    func parserDidEndDocument(_ parser: XMLParser) {
        print(arrAllData)
    }
}

