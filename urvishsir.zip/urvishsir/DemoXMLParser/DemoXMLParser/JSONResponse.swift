//
//  JSONResponse.swift
//  DemoXMLParser
//
//  Created by agile-2 on 22/11/18.
//  Copyright © 2018 agilemac-24. All rights reserved.
//

//{   "status":1,
//    "message":"TEST MESSAGE",
//    "data":{
//        "message":"test",
//        "last_month_date":"2018-10-23T10:23:29.245Z"
//    }
//}
