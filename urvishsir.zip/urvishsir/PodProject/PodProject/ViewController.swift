//
//  ViewController.swift
//  PodProject
//
//  Created by agile-2 on 04/10/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtFirstName:UITextField!
    @IBOutlet var txtLastName:UITextField!
    @IBOutlet var txtMiddleName:UITextField!
    @IBOutlet var txtEmail:UITextField!
    @IBOutlet var txtPhoneNumber:UITextField!
    @IBOutlet var txtHomeNumber:UITextField!
    @IBOutlet var txtWorkNumber:UITextField!
    @IBOutlet var txtAddress1:UITextField!
    @IBOutlet var txtAddress2:UITextField!
    @IBOutlet var txtPassword:UITextField!
    @IBOutlet var txtConfirmPassword:UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

