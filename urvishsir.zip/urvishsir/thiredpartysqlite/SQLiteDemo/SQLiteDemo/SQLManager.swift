//
//  SQLManager.swift
//  SQLiteDemo
//
//  Created by agile-2 on 20/11/18.
//  Copyright © 2018 agilemac-24. All rights reserved.
//

import UIKit
import GRDB


class SQLManager: NSObject {
    
    static let shared:SQLManager = SQLManager()
    
    var dbPool:DatabasePool?
    
    override init() {
        super.init()
        do{
            print("\(SDFileManager.shared.documentDirectoryPath)/newDatabase.sqlite")
            
            dbPool = try DatabasePool(path: "\(SDFileManager.shared.documentDirectoryPath)/newDatabase.sqlite")
           
            if !SDFileManager.shared.checkFileAvailableInLocalDirectory(withFileName: "newDatabase.sqlite") {
                self.createTable()
            }
        }catch {
            print(error.localizedDescription)
        }
        
    }
    
    
    
    func createTable(){
        
        do{
            try dbPool?.write { db in
                try db.execute("""
        CREATE TABLE player (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            score INT)
        """)
                
//                try db.create(table: "tblUSer", body: { (tabl) in
//                    tabl.column("id", Database.ColumnType.integer)
//                    tabl.column("id", Database.ColumnType.integer)
//                    tabl.column("id", Database.ColumnType.integer)
//                    tabl.column("id", Database.ColumnType.integer)
//
//                })
//
//                try db.execute("Insert into tblUser (id) values (100) ")
            }
            
        }catch {
            print(error.localizedDescription)
        }
    }
    
    func insertRecord(){
        do{
            
            try dbPool?.write { db in
                try db.execute(
                    "INSERT INTO player (name, score) VALUES (?, ?)",
                    arguments: ["Barbara", 100011])
                
                try db.execute(
                    "UPDATE player SET score = :score WHERE id = :id",
                    arguments: ["score": 1000987, "id": 1])
                
            }
            
        }catch {
            print(error.localizedDescription)
        }
    }
    
    func selectRecords(){
        do{
            try dbPool?.read { db in
                //                if let row = try Row.fetchOne(db, "SELECT * FROM wine WHERE id = ?", arguments: [1]) {
                //                    let name: String = row["name"]
                //
                //                    print(name, color)
                //                }
                if let rows:[Row] = try Row.fetchAll(db, "SELECT * FROM player") {
                    for row in rows {
                        let score: Int = row["score"]
                        let name: String = row["name"]
                        
                        print("Name:\(name) Score : \(score)")
                    }
                }
                
            }
            
        }catch {
            print(error.localizedDescription)
        }
    }
    
    
}
