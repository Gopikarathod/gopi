//
//  ViewController.swift
//  SwitchAndSegment
//
//  Created by Meet Patel on 04/10/18.
//  Copyright © 2018 Meet Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var SwitchState: UISwitch!
    @IBOutlet weak var SegmentView: UISegmentedControl!
    @IBOutlet weak var ViewData: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func SwitchAction(sender: UISwitch) {
        if SwitchState.isOn {
            SegmentView.isEnabled = true
        }
        else {
            SegmentView.isEnabled = false
            ViewData.backgroundColor = UIColor.clear
        }
    }
    
    @IBAction func SegmentAction(Segment:UISegmentedControl) {
        if SegmentView.selectedSegmentIndex == 0 {
            ViewData.backgroundColor = UIColor.red
        }
        else {
            ViewData.backgroundColor = UIColor.blue
        }
    }

}

