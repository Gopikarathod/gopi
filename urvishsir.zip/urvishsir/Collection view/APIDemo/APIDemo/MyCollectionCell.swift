//
//  MyCollectionCell.swift
//  APIDemo
//
//  Created by agile-2 on 26/11/18.
//  Copyright © 2018 agilemac-24. All rights reserved.
//

import UIKit

class MyCollectionCell: UICollectionViewCell {
    @IBOutlet weak var lblName:UILabel!
    
    
}
