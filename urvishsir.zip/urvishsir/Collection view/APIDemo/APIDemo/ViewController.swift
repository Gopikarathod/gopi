//
//  ViewController.swift
//  APIDemo
//
//  Created by agilemac-24 on 1/30/18.
//  Copyright © 2018 agilemac-24. All rights reserved.
//

import UIKit
import Alamofire
enum DownloadStatus  {
    case None
    case Pending
    case Failed(reason:String)
    case Success
    
}


/*
1) method Type : get
url :http://202.131.117.92:7024/v1/api/test

2)Method Type : post
url : http://202.131.117.92:7024/v1/api/getUserDetail
parameters :
user_id : 5a61df2e4f2dd92403f9c629
*/


class ViewController: UIViewController,UICollectionViewDataSource {

    let objEnum:DownloadStatus = DownloadStatus.Failed(reason: "hello")
    
    @IBOutlet weak var collectionView:UICollectionView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.postMethod()
        
        self.collectionView.dataSource = self
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    func postMethod()
    {
        let dictPerameters:[String:String] = ["user_id":"5a61df2e4f2dd92403f9c629"]
        
        let manager = Alamofire.SessionManager.default
        manager.request(URL.init(string: "http://202.131.117.92:7024/v1/api/getUserDetail")!, method: HTTPMethod.post, parameters: dictPerameters, encoding: URLEncoding.default, headers: nil).responseJSON { (response) in
            switch response.result
            {
            case .success(let json):
            
                print(json)
                
                if let dict:[String:Any] = json as? [String:Any]
                {
                    if let strMessage:String = dict["message"] as? String
                    {
                        print(strMessage)
                    }
                    
                }
                break;
                
            case .failure(_):
            
               
                print("Response Status Code :: \(String(describing: response.response?.statusCode))")
                let datastring = NSString(data: response.data!, encoding: String.Encoding.utf8.rawValue)
                print(datastring ?? "Test")
                
                break;
                
            }
        }
    }
    func getMethod()
    {
        
    }
    
    
    
    
}



