//
//  ViewController_CollectionView.swift
//  APIDemo
//
//  Created by agile-2 on 26/11/18.
//  Copyright © 2018 agilemac-24. All rights reserved.
//

import UIKit

extension ViewController{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1000
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell:MyCollectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCollectionCellIdentifier", for: indexPath) as? MyCollectionCell
        {
           
            cell.lblName.text = "Index : \(indexPath.row)"
            return cell
        }
        return UICollectionViewCell()
        
    }
    
}

