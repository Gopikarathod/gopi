//
//  ViewController.swift
//  DemoLocalNotification
//
//  Created by agilemac-24 on 2/7/18.
//  Copyright © 2018 agilemac-24. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController,UNUserNotificationCenterDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.checkPermission()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func registerDevice(application:UIApplication) -> Void
    {
        
        if #available(iOS 10.0, *)
        {
            let center = UNUserNotificationCenter.current()
            center.delegate = self
            
            center.requestAuthorization(options: [.sound,.alert,.badge], completionHandler: { (granted, error) in
                if granted
                {
                    DispatchQueue.main.async {
                        UIApplication.shared.registerForRemoteNotifications()
                    }
                }
            })
        }
        else
        {
            let notificationTypes : UIUserNotificationType = [UIUserNotificationType.alert , UIUserNotificationType.sound , UIUserNotificationType.badge]
            let pushNotificationSettings = UIUserNotificationSettings(types: notificationTypes, categories: nil)
            UIApplication.shared.registerUserNotificationSettings(pushNotificationSettings)
            UIApplication.shared.registerForRemoteNotifications()
        }
        
    }
    func checkPermission()
    {
        
        if #available(iOS 10.0, *) {
            let center = UNUserNotificationCenter.current()
            center.delegate = self
            
            center.requestAuthorization(options: [.sound,.alert,.badge], completionHandler: { (granted, error) in
                if granted
                {
                    DispatchQueue.main.async {
                        self.testNotification()
                    }
                }
                else
                {
                    ///Dispay Error
                }
            })
            
        } else {
            // Fallback on earlier versions
        }
        
    }

    func testNotification()
    {
       if #available(iOS 10.0, *) {
        
        
            //iOS 10 or above version
            let content = UNMutableNotificationContent()
            content.title = "Title"
            content.body = "Body"
            content.subtitle = "Sub Title"
            content.badge = 10
            content.sound = UNNotificationSound.default()
        
        /*
         let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 300,
         repeats: false)
         
         let date = Date(timeIntervalSinceNow: 3600)
         let triggerDate = Calendar.current.dateComponents([.year,.month,.day,.hour,.minute,.second,], from: date)
         
         let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDate,
         repeats: false)
         
         let triggerDaily = Calendar.current.dateComponents([hour,.minute,.second,], from: date)
         let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDaily, repeats: true)
         
         
         */
        
        
        
        let date = Date(timeIntervalSinceNow: 60)
        let dateFormat:DateFormatter = DateFormatter()
        dateFormat.dateFormat = "yyyy-MM-dd hh:mm:ss z"
        let strDate:String = dateFormat.string(from: date)
        print(strDate)
        let triggerDate = Calendar.current.dateComponents([.year,.month,.day,.hour,.minute,.second,], from: date)
       
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDate,
                                                    repeats: false)
        
        //let trigger1 = UNTimeIntervalNotificationTrigger(timeInterval: 5,                                                     repeats: false)
      
        ///GetPending Notification List
        UNUserNotificationCenter.current().getPendingNotificationRequests(completionHandler: { (notification) in
            for n in notification
            {
                print(n.identifier)
            }
        })
        
        
        
            let request = UNNotificationRequest(identifier:"\(strDate)", content: content, trigger: trigger)
            print(request.trigger)
            UNUserNotificationCenter.current().delegate = self
            UNUserNotificationCenter.current().add(request){(error) in
                if error != nil {
                    print(error?.localizedDescription ?? "")
                }
               
            }
        } else
        {
            // iOS 9
            let notification = UILocalNotification()
            notification.fireDate = self.getDate()
            notification.alertTitle = "Title"
            notification.alertBody = "Body"
            notification.applicationIconBadgeNumber = 10
            notification.soundName = UILocalNotificationDefaultSoundName
            
        UIApplication.shared.scheduleLocalNotification(notification)
            
        }
    }
    private func registerForNotification() {
        //Requesting Authorization for User Interactions
        if #available(iOS 10.0, *) {
            let center = UNUserNotificationCenter.current()
            
            center.requestAuthorization(options: [.alert, .sound]) { (granted, error) in
                // Enable or disable features based on authorization.
                if granted {
                    // print("granted")
                    
                } else {
                    // print("denied")
                }
            }
        }
        else
        {  UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.sound, .alert], categories: nil))
        }
    }
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Swift.Void)
    {
        print(response.notification)
    }
    
    
    func getDate() -> Date
    {
       // let currentDate:Date = Date()
        return Date.init(timeIntervalSince1970: 20)
        
    }
    
}

