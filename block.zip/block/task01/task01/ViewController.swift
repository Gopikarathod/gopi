//
//  ViewController.swift
//  task01
//
//  Created by agile-10 on 24/08/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{
   
    

    

    @IBOutlet var tblinfo:UITableView!
    
    var viewdata:[[String:String]] = []
    let objemp = empdataViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()       
        print(self)
        let objbarbtn:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonSystemItem.add, target: self, action: #selector(ViewController.submit))
        self.navigationItem.rightBarButtonItem = objbarbtn
        
       
        self.tblinfo.dataSource = self
        self.tblinfo.delegate = self
        
      objemp.data{ viewdata in
               let obj = objemp.info as! String
        
        }
            
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  override  func viewWillAppear(_ animated: Bool) {
        self.tblinfo.reloadData()
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewdata.count
    }
    @IBAction func submit() {
        
        if let objemp:empdataViewController = storyboard?.instantiateViewController(withIdentifier: "empdataViewController") as? empdataViewController {
            
            self.navigationController?.pushViewController(objemp, animated: true)
            
        }
    }
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
let call:dataTableViewCell = tableView.dequeueReusableCell(withIdentifier: "dataTableViewCell") as! dataTableViewCell
       call.accessoryType = UITableViewCellAccessoryType.disclosureIndicator
    
    let obj = self.viewdata[indexPath.row]
   
    call.fnm.text = obj["fname"]
    call.Lnm.text = obj["lname"]
    call.Desig.text = obj["designation"]
    
     return call
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
       
    }
    
}

