//
//  empdataViewController.swift
//  task01
//
//  Created by agile-10 on 24/08/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

struct empinfo {
    static let id:String = "id"
    static let fname:String = "fname"
    static let lname:String = "lname"
    static let city:String = "city"
    static let state:String = "state"
    static let country:String = "country"
    static let bloodgroup:String = "bloodgroup"
    static let mobilenum:String = "mobilenum"
    static let homenum:String = "homenum"
    static let designation:String = "designation"
    static let about:String = "about"
}
class empdataViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate{
    
    @IBOutlet var emptabl:UITableView!
    
   
   var info:[String:String] = [:]
    var arrdetail:[[String:String]] = []
    
    override func viewDidLoad() {
        
        
        
        self.title = "Add emp"
        
        self.emptabl.dataSource = self
        self.emptabl.delegate = self
    
       // self.emptabl.estimatedRowHeight = 44.0
        
        super.viewDidLoad()
       

        // Do any additional setup after loading the view.
    }
    func  data(Completion:((_ value:String) -> Void)) {
       
        let obj = arrdetail as! String
        Completion(obj)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 12
    }
   
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if(indexPath.row < 11)
        {
            if let cell:empcell=tableView.dequeueReusableCell(withIdentifier: "empcell") as? empcell
            {
                cell.txtmain.delegate = self
                cell.txtmain.tag = indexPath.row
                if(indexPath.row == 0)
                {
                    cell.lblmain.text = "Id"
                    cell.txtmain.isEnabled = false
                    cell.txtmain.text = info[empinfo.id]
                  
                    
                }
                else if(indexPath.row == 1)
                {
                    cell.lblmain.text = "First Name"
                    cell.txtmain.becomeFirstResponder()
                    cell.txtmain.text = info[empinfo.fname]
                    cell.txtmain.isEnabled = true
                }
                else if(indexPath.row == 2)
                {
                    cell.lblmain.text = "Last Name"
                    cell.txtmain.text = info[empinfo.lname]
                    cell.txtmain.isEnabled = true
                }
                else if(indexPath.row == 3)
                {
                    cell.lblmain.text = "City"
                    cell.txtmain.text = info[empinfo.city]
                    cell.txtmain.isEnabled = true
                }
                else if(indexPath.row == 4)
                {
                    cell.lblmain.text = "State"
                    cell.txtmain.text = info[empinfo.state]
                    cell.txtmain.isEnabled = true
                }
                else if(indexPath.row == 5)
                {
                    cell.lblmain.text = "Country"
                    cell.txtmain.text = info[empinfo.country]
                    cell.txtmain.isEnabled = true
                }
                else if(indexPath.row == 6)
                {
                    cell.lblmain.text = "Blood Group"
                    cell.txtmain.text = info[empinfo.bloodgroup]
                    cell.txtmain.isEnabled = true
                }
                else if(indexPath.row == 7)
                {
                    cell.lblmain.text = "Mobile Num"
                    cell.txtmain.text = info[empinfo.mobilenum]
                    cell.txtmain.isEnabled = true
                  //  cell.txtmain.text = "+91"
                }
                else if(indexPath.row == 8)
                {
                    cell.lblmain.text = "Home Num"
                    cell.txtmain.text = info[empinfo.homenum]
                    cell.txtmain.isEnabled = true
                }
                else if(indexPath.row == 9)
                {
                    cell.lblmain.text = "Designation"
                    cell.txtmain.text = info[empinfo.designation]
                    cell.txtmain.isEnabled = true
                }
                else if(indexPath.row == 10)
                {
                    cell.lblmain.text = "About"
                    cell.txtmain.text = info[empinfo.about]
                    cell.txtmain.isEnabled = true
                }
                
                return cell
            }
        }
        else
        {
            if let cell:empcell=tableView.dequeueReusableCell(withIdentifier: "empcell1") as? empcell
            {
                cell.btnmain.setTitle("Add", for: .normal)
                cell.btnmain.addTarget(self, action: #selector(submit), for: UIControlEvents.touchUpInside)
                cell.btnmain.backgroundColor = UIColor.black
                cell.btnmain.setTitleColor(.white, for: .normal)
                return cell
            }
            
        }
        return UITableViewCell.init(style: .default, reuseIdentifier: "cell")
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField.tag == 0 {
            info[empinfo.id] = textField.text!
            
        }
         else if textField.tag == 1 {
            info[empinfo.fname] = textField.text!
       }
        else if textField.tag == 2 {
            info[empinfo.lname] = textField.text!
        }
        else if textField.tag == 3 {
            info[empinfo.city] = textField.text!
        }
        else if textField.tag == 4 {
            info[empinfo.state] = textField.text!
        }
        else if textField.tag == 5 {
            info[empinfo.country] = textField.text!
        }
        else if textField.tag == 6 {
            info[empinfo.bloodgroup] = textField.text!
        }
        else if textField.tag == 7 {
            info[empinfo.mobilenum] = textField.text!
        }
        else if textField.tag == 8 {
            info[empinfo.homenum] = textField.text!
        }
        else if textField.tag == 9{
            info[empinfo.designation] = textField.text!
        }
        else if textField.tag == 10 {
            info[empinfo.about] = textField.text!
        }
       
        
    }
   
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if (textField.tag == 0){
            return becomeFirstResponder()
        }
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
    
        
        if string == "" {
            return true
        }
        
            
       let objcharset = CharacterSet.init(charactersIn:"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ '")
     let objchar = CharacterSet.init(charactersIn:"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
        let objnum = CharacterSet.init(charactersIn:"1234567890")
        
        if ((textField.tag == 1) || (textField.tag == 2)){
            
        
            if let _:Range = string.rangeOfCharacter(from: objcharset)
            {
                 return true
            }
        
        else{
            return false
            }
        }
          if ((textField.tag == 3) || (textField.tag == 4) || (textField.tag == 5)){
            if let _:Range = string.rangeOfCharacter(from: objchar)
            {
                return true
            }
                
            else{
                return false
            }
       
        }
    
        
        if (textField.tag == 6)
        {
            if range.location >= 3{
                return false
            }
            let objcharset = CharacterSet.init(charactersIn:"+-aboABO")
            if let _:Range = string.rangeOfCharacter(from: objcharset){
                return true
            }
            else
            {
                return false
            }
            
            
        }
        
        if ((textField.tag == 7) || (textField.tag == 8) )
        {
            if range.location >= 15{
                return false
            }
            
            if let _:Range = string.rangeOfCharacter(from: objnum){
                return true
            }
            else
            {
                return false
            }
            
        }
        return true
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       
        return 70
        
    }
    
    @objc func submit(){
        
        self.view.endEditing(true)
        
        arrdetail.append(info)
        
       
                 self.navigationController?.popViewController(animated: true)
     
    }
}

