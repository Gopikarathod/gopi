//
//  ViewController.swift
//  datapicker
//
//  Created by agile-10 on 12/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate{
    
    @IBOutlet var datepicker:UIPickerView!
    @IBOutlet var txtdate:UITextField!
    @IBOutlet var myview:UIView!
    var mm = ""
    var dd = ""
    var yyyy = ""
 //   var date = [["1","2","3","4","5","6","7","8","9","10"],["1","2","3","4","5","6","7","8","9","10","11","12"],["2010","2011","2012","2013","2014","2015","2016","2017","2018"]]
    
    var date = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]
    var month = [1,2,3,4,5,6,7,8,9,10,11,12]
    var year = [2010,2011,2012,2013,2014,2015,2016,2017,2018]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.datepicker.dataSource = self
        self.datepicker.delegate = self
        self.datepicker.isHidden = true
        self.txtdate.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
         self.datepicker.isHidden = false
        
        return true
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (component == 0 ){
            return date.count
        } else if (component == 1){
            return month.count
        }else if (component == 2){
            return year.count
        }
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if (component == 0){
            return "\(date[row])"
        }else if (component == 1){
            return "\(month[row])"
        }else if (component == 2){
            return "\(year[row])"
        }
        return "1"
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (component == 0){
                dd = "\(date[row])"
//            txtdate.text = dd
        }
       else if (component == 1){
                mm = "\(month[row])"
//            txtdate.text = mm
        }
        else if (component == 2){
                yyyy = "\(year[row])"
//            txtdate.text = yyyy
        }
//         txtdate.text = "\(date[row])  \(month[row]) \(year[row])"
//
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btndone(){
        
        txtdate.text = dd + "/" + mm + "/" + yyyy
    }

    @IBAction func btncancle(){
        
        txtdate.text = ""
    }

}

