//
//  ContactViewController.swift
//  ContactApp
//
//  Created by agile-2 on 19/09/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

class ContactViewController: UIViewController,UISearchBarDelegate {
    
    @IBOutlet weak var tblContact:ContactTableView!
      @IBOutlet weak var searchBar:UISearchBar!
    
    var aryContacts:[Contact] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupUI(){
        let firstValue:Contact = Contact.init()
        let secondValue:Contact = Contact.init(withName: "ABC", withLastName: "1")
        let thirdValue:Contact = Contact.init(withName: "PQR", withLastName: "2", withNumber: "")
        
        self.tblContact.setDataInTableView(withContacts: [firstValue,secondValue,thirdValue])
        self.tblContact.didSetContactSelectionHandler { (contact) in
            print(contact.strFirstName)
            
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
