//
//  ContactCell.swift
//  ContactApp
//
//  Created by agile-2 on 19/09/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

class ContactCell: UITableViewCell {

    @IBOutlet weak var lblName:UILabel!
    @IBOutlet weak var lblNumber:UILabel!
    
    
    private var objContact:Contact = Contact()
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setDataInCell(withModel model:Contact) {
        self.objContact = model
        self.lblName.text = self.objContact.strLastName
        self.lblNumber.text = self.objContact.strNumber
        
    }
}
