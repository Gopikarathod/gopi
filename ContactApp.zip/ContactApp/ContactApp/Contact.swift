//
//  Contact.swift
//  ContactApp
//
//  Created by agile-2 on 19/09/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

class Contact: NSObject {
    var strFirstName:String = ""
    var strNumber:String = ""
    var strLastName:String = ""
    private var date:Date?
    override init() {
        strFirstName = ""
        strNumber = ""
        self.strLastName = ""
        
    }
    init(withName name:String,withLastName lName:String,withNumber number:String) {
        self.strNumber = number
        self.strFirstName = name
        self.strLastName = lName
    }
    init(withName name:String,withLastName lName:String) {
        self.strNumber = ""
        self.strFirstName = name
        self.strLastName = lName
        self.date = Date()
    }
    
}
