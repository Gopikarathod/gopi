//
//  ContactTableView.swift
//  ContactApp
//
//  Created by agile-2 on 19/09/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

class ContactTableView: UITableView,UITableViewDelegate,UITableViewDataSource {

    var aryContactInTableView:[Contact] = []
    private var didSelectContact:((Contact) -> Void )?
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    func didSetContactSelectionHandler(withHandler handler:@escaping ((Contact) -> Void )){
        self.didSelectContact = handler
    }
    func setDataInTableView(withContacts contacts:[Contact]){
        self.aryContactInTableView = contacts
        self.delegate = self
        self.dataSource = self
        self.reloadData()
        
        
        let objRefreshControl = UIRefreshControl()
        objRefreshControl.addTarget(self, action: #selector(refreshTableView), for: UIControlEvents.valueChanged)
        objRefreshControl.tintColor = UIColor.red
        self.refreshControl = objRefreshControl
    //    self.refreshControl
        
        self.scrollRectToVisible(<#T##rect: CGRect##CGRect#>, animated: <#T##Bool#>)
    }
    @objc func refreshTableView(){
        print("refresh")
        self.reloadData()
        
        self.refreshControl?.endRefreshing()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryContactInTableView.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let objContact:Contact = self.aryContactInTableView[indexPath.row]
//        let cell:UITableViewCell = UITableViewCell.init(style: .default, reuseIdentifier: "cell")
//        cell.textLabel?.text = objContact.strLastName
        let cell:ContactCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! ContactCell
        cell.setDataInCell(withModel: objContact)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let value = self.didSelectContact {
            let objContact:Contact = self.aryContactInTableView[indexPath.row]
            value(objContact)
        }
    }
}
