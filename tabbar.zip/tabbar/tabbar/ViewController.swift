//
//  ViewController.swift
//  tabbar
//
//  Created by agile-10 on 20/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func click(){
        
        let objthired:thiredViewController = (storyboard?.instantiateViewController(withIdentifier: "thiredViewController") as? thiredViewController)!
        
        self.navigationController?.pushViewController(objthired, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

