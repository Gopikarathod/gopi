//
//  ViewController.swift
//  student_dist
//
//  Created by agile-02 on 19/07/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
@IBOutlet    var stdid:UILabel!
@IBOutlet     var stdname:UILabel!
@IBOutlet     var stdaddress:UILabel!
@IBOutlet   var prnt:UIButton!

    
    
    
    var stddic:[Int:Any]=[:]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.stud(withname: "gopi", withaddress: "botad", withnumber:"8962355544", withmarks:"65")
        self.stud(withname: "radhi", withaddress: "ahmedabad", withnumber:"6325874199", withmarks:"80")
        self.stud(withname: "dipee", withaddress: "bhavnager", withnumber:"7896541239", withmarks:"60")
        
            studdispaly()
            print("\n")
            studupdate(withstudid: 3,withanyinfo:"2586397",withanykey: "number")
            studdispaly()
            print("\n")
            studdelete(withstudid: 2)
            studdispaly()
      
        stdid = UILabel.init(frame: CGRect.init(x: 30, y: 100, width: 1000, height: 50))
            self.view.addSubview(stdid)
        
        stdname = UILabel.init(frame: CGRect.init(x: 30, y: 150, width: 500, height: 50))
        self.view.addSubview(stdname)
        
        stdaddress = UILabel.init(frame: CGRect.init(x: 30, y: 200, width:500, height: 50))
        self.view.addSubview(stdaddress)
        
        
            prnt = UIButton.init(frame: CGRect.init(x: 30, y: 300, width: 150, height: 50))
            prnt.addTarget(self, action: #selector(prntclick), for: UIControlEvents.touchUpInside)
            prnt.setTitle("print", for: UIControlState.normal)
            prnt.backgroundColor = UIColor.black

            self.view.addSubview(prnt)
        
       
        // Do any additional setup after loading the view, typically from a nib.
    }

    /// <#Description#>
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    
    
    func stud(withname name:String,withaddress address:String,withnumber number:String,withmarks marks:String){
        let studdata:[String:Any] = ["name":name,"address":address,"number":number,"marks":marks]
    
         stddic[stddic.count+1] = studdata
        
       
        
        
        
    }
    func studdelete(withstudid studid:Int){
       
        
       
            stddic.removeValue(forKey: studid)
        

        }
    
   func studupdate(withstudid studid:Int,withanyinfo info:String,withanykey anykey:String){
        
        for (key,value) in stddic
        {
            var stdup:[String:String]=(value as? [String:String])!
            if(studid == key)
            {
                stdup.updateValue(info, forKey: anykey)
                stddic[key]=stdup
                break
            }
    }
    
    }
    

        
    func studdispaly(){
        for (key,value) in stddic
        {
            print(key)
            let studic:[String:String] = (value as? [String:String])!
            
            for (key,value) in studic
            {
                print("\(key):\(value)")
            }
        }
        }

    
    @IBAction func prntclick() {
        
        
        for (key,value) in stddic{
            
            let studarr = value  as! [String:String]
        if(key==1)
        {
            stdid.text = "ID:\(key)"
            for(key,_) in studarr
            {
                if(key == "name")
                {
                    stdname.text="\(key):\(studarr["name"]!)"
                }
                
                if(key == "address")
                {
                    stdaddress.text="\(key):\(studarr["address"]!)"
                }
                
                
                
                
                
            }
            }
        }
      
}
}


