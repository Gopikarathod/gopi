//
//  empcell.swift
//  task01
//
//  Created by agile-10 on 24/08/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class empcell: UITableViewCell {

    @IBOutlet var lblmain:UILabel!
    @IBOutlet var txtmain:UITextField!
    @IBOutlet var btnmain:UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
