//
//  ViewController.swift
//  corelocation
//
//  Created by agile-10 on 08/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate{

   
    let objlocation:CLLocationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        objlocation.delegate = self
      // objlocation.requestLocation()
        
            CLLocationManager.authorizationStatus()
            objlocation.requestAlwaysAuthorization()
            objlocation.requestWhenInUseAuthorization()
        
        
        
       // objlocation.desiredAccuracy = kCLLocationAccuracyBest
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    

    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
    
        print("update")
    }
    
   func locationManager(_ manager: CLLocationManager, didFailWithError error: Error)
    {
        print(error.localizedDescription)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

