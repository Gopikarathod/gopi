//
//  TableViewCell.swift
//  tableview under collectionview
//
//  Created by agile-10 on 12/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet var coll:UICollectionView!

    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
