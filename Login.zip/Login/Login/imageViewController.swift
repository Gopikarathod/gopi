//
//  imageViewController.swift
//  Login
//
//  Created by agile-10 on 12/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class imageViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    
    
    @IBOutlet var collection:UICollectionView!
    var arrimg:[UIImage] = [UIImage.init(named: "10.jpg")!,UIImage.init(named: "1.jpg")!,UIImage.init(named: "2.jpg")!,UIImage.init(named: "4.jpg")!]
    var selectImg:UIImage!
    var arrtemp:[UIImage] = []
    var flag = 0
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let item = UIBarButtonItem.init(title: "Image", style: .plain, target: self, action: #selector(btnImage))
        
        self.navigationItem.rightBarButtonItem = item
        
        collection.delegate = self
        collection.dataSource = self

        // Do any additional setup after loading the view.
    }
    @objc func btnImage(){
        flag = 0
        let imagepicker:UIImagePickerController = UIImagePickerController()
        imagepicker.delegate = self
        imagepicker.sourceType = .photoLibrary
        self.present(imagepicker, animated: true, completion: nil)
    }
    override func viewWillAppear(_ animated: Bool) {
        collection.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if flag == 0{
            return arrimg.count
        }else{
            return arrtemp.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:CollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell 
        if flag == 0{
            let obj = arrimg[indexPath.row]
            cell.img.image = obj
        }else{
            let temp = arrtemp[indexPath.row]
            cell.img.image = temp
        }
        return cell
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]){
        selectImg = info[UIImagePickerControllerOriginalImage] as! UIImage
        self.arrimg.append(selectImg)
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        dismiss(animated: true, completion: nil)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        arrtemp = []
        let select = arrimg[indexPath.row]
        
        for image in arrimg{
            if image == select {
                arrtemp.append(image)
                print(arrtemp)
         }

        }
        
        flag = 1
        collection.reloadData()
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
