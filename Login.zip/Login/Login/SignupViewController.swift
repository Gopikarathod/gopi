//
//  SignupViewController.swift
//  Login
//
//  Created by agile-10 on 08/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController,UITextFieldDelegate{
    
    @IBOutlet var txtfirst:UITextField!
    @IBOutlet var txtlast:UITextField!
    @IBOutlet var txtuser:UITextField!
    @IBOutlet var txtemail:UITextField!
    @IBOutlet var txtphone:UITextField!
    @IBOutlet var txtaddress:UITextField!
    @IBOutlet var txtdob:UITextField!
    @IBOutlet var txtgender:UITextField!
    @IBOutlet var txtpassword:UITextField!
    @IBOutlet var txtconformpass:UITextField!
    var dictionry:[String:Any] = [:]

   
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtpassword.delegate = self
        txtconformpass.delegate = self
        txtgender.delegate = self
        txtaddress.delegate = self
        txtdob.delegate = self
        txtemail.delegate = self
        txtlast.delegate = self
        txtfirst.delegate = self
        txtuser.delegate = self
        txtphone.delegate = self

        // Do any additional setup after loading the view.
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let objchar = CharacterSet.init(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
        
        let objnum = CharacterSet.init(charactersIn: "0123456789")
        if string == "" {
            return true
        }
      
        if (textField == txtfirst) || (textField == txtlast) || (textField == txtuser){
            if let _:Range = string.rangeOfCharacter(from: objchar){
                return true
            }else{
                return false
            }
        }
        
        if (textField == txtphone) || (textField == txtdob){
            if let _:Range = string.rangeOfCharacter(from: objnum){
                return true
            }else{
                return false
            }
        }
        
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    @IBAction  func btnSave(){
        let objapp = UIApplication.shared.delegate as? AppDelegate
        dictionry = ["first":txtfirst.text as Any,"last":txtlast.text as Any,"user":txtuser.text as Any,"email":txtemail.text as Any,"phone":txtphone.text as Any,"address":txtaddress.text as Any,"dob":txtdob.text as Any,"gender":txtgender.text as Any,"password":txtpassword.text as Any,"conform":txtconformpass.text as Any]
        
        
        if (txtfirst.text?.isEmpty)! || (txtlast.text?.isEmpty)! || (txtuser.text?.isEmpty)! || (txtemail.text?.isEmpty)! || (txtphone.text?.isEmpty)! || (txtaddress.text?.isEmpty)! || (txtdob.text?.isEmpty)! || (txtgender.text?.isEmpty)! || (txtpassword.text?.isEmpty)! || (txtconformpass.text?.isEmpty)!{
            
            print(objapp?.arrsignup ?? "")
            
        }else{
            
            if (txtemail.text?.isValidEmail())!{
                print("right")
                
            }else{
                print("Enter Correct email")
            }
            
            if txtgender.text == "female" && txtgender.text == "male"{
                print("right")
            }else{
                print("enter female/male")
            }
            
            
            if txtpassword.text == txtconformpass.text{
                objapp?.arrsignup.append(dictionry)
                print(objapp?.arrsignup ?? "")
                UserDefaults.standard.set(objapp?.arrsignup, forKey: "Signup")
                UserDefaults.standard.synchronize()
                
                txtfirst.text = ""
                txtlast.text = ""
                txtuser.text = ""
                txtemail.text = ""
                txtphone.text = ""
                txtdob.text = ""
                txtgender.text = ""
                txtaddress.text = ""
                txtpassword.text = ""
                txtconformpass.text = ""
            }else{
                print("Password or conformpassword not Same")
            }
        }
        
        

    }
    
}

extension String {
    func isValidEmail() -> Bool {
        let regex = try? NSRegularExpression(pattern: "^(((([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])+(\\.([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])+)*)|((\\x22)((((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(([\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]|\\x21|[\\x23-\\x5b]|[\\x5d-\\x7e]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(\\([\\x01-\\x09\\x0b\\x0c\\x0d-\\x7f]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}]))))*(((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(\\x22)))@((([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])([a-zA-Z]|\\d|-|\\.|_|~|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])*([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])))\\.)+(([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])([a-zA-Z]|\\d|-|_|~|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])*([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])))\\.?$", options: .caseInsensitive)
        return regex?.firstMatch(in: self, options: [], range: NSMakeRange(0, self.count)) != nil
        }
    }

