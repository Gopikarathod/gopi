//
//  ViewController.swift
//  Login
//
//  Created by agile-10 on 08/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate{
    
    @IBOutlet var txtEmail:UITextField!
    @IBOutlet var txtPassword:UITextField!
    let appdel = UIApplication.shared.delegate as? AppDelegate

    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        txtEmail.delegate = self
        txtPassword.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    @IBAction func btnLogin(){
        
        if (txtEmail.text?.isEmpty)! || (txtPassword.text?.isEmpty)!{
            print("Enter data")
        }else{
            for i in (appdel?.arrsignup)!{
                if (i["email"] as? String == txtEmail.text) || (i["password"] as? String == txtPassword.text)
                {
                    let objimg:imageViewController = (storyboard?.instantiateViewController(withIdentifier: "imageViewController") as? imageViewController)!
                    
                    self.navigationController?.pushViewController(objimg, animated: true)
                }else{
                    print("incorrect email & password")
                }
            }
        }
    }
    
    @IBAction func btnSignup(){
        
        let objsignup:SignupViewController = (storyboard?.instantiateViewController(withIdentifier: "SignupViewController") as? SignupViewController)!
        
        self.navigationController?.pushViewController(objsignup, animated: true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

