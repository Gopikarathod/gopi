//
//  CollectionViewCell.swift
//  Login
//
//  Created by agile-10 on 12/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var img:UIImageView!
    
}
