//
//  SecondViewController.swift
//  switchsagmentserchbar
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate{
    
    @IBOutlet var tblsecond:UITableView!
    @IBOutlet var search:UISearchBar!
    var arrsecond:[String] = ["gopika","radhika","dipeeka","ritu","pooja","brijesh","vishal","bunty","nitiraj","harshad","nirali","krupali","sagar","sejal","dipak","prakit","ravi","pintu","nirmal","nisha","aarav"]
    //var i = 0
    var data:[String] = []
    let objrefresh:UIRefreshControl = UIRefreshControl()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tblsecond.dataSource = self
        self.tblsecond.delegate = self
        self.search.delegate = self
        data = arrsecond
        
        
        objrefresh.addTarget(self, action: #selector(refresh), for: .valueChanged)
        tblsecond.refreshControl = objrefresh
       
        // Do any additional setup after loading the view.
    }
    
    @objc func refresh(){
       
        if (search.text?.isEmpty)! {
            print("Nil")
     //       tblsecond.refreshControl?.endRefreshing()
        }
        else {
            print("Not Nil")
             viewDidLoad()
             tblsecond.reloadData()
            //search.text = nil
            //data = arrsecond
        }
          tblsecond.refreshControl?.endRefreshing()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(data)
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:SecondTableViewCell = tableView.dequeueReusableCell(withIdentifier: "SecondTableViewCell") as! SecondTableViewCell
     //   let obj:[String] = [arrsecond[indexPath.row]]
        print(cell.txt.text ?? "")
        cell.txt.text = data[indexPath.row]
        
        
       /* if (i == arrsecond.count+1){
            i = 0
        }else{
            i = i + 1
        }*/
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.search.text = ""
        viewDidLoad()
        tblsecond.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        data = searchText.isEmpty ? arrsecond : arrsecond.filter({ (second) -> Bool in
          //  return (second.range(of: searchText) != nil)
            return (second.range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil)
        })
        tblsecond.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
