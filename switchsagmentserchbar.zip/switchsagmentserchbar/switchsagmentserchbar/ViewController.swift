//
//  ViewController.swift
//  switchsagmentserchbar
//
//  Created by agile-10 on 01/01/01.
//  Copyright © 2001 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var swich:UISwitch!
    @IBOutlet var segment:UISegmentedControl!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func switchAction(){
           print(swich.isOn) 
    }
    @IBAction func sugmentAction(){ 
        
        if segment.selectedSegmentIndex == 0 {
            let objthired:thiredViewController = storyboard?.instantiateViewController(withIdentifier: "thiredViewController") as! thiredViewController
            self.navigationController?.pushViewController(objthired, animated: true)
        } else{
            
            let objfour:FourViewController = (storyboard?.instantiateViewController(withIdentifier: "FourViewController") as? FourViewController)!
            self.navigationController?.pushViewController(objfour, animated: true)
        }
        
        
    }
}

