//
//  ViewController.swift
//  sague
//
//  Created by agile-10 on 28/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
      //  performSegue(withIdentifier: "seguetechar", sender: self)
        if segue.identifier == "seguetechar"
        {
         //   let objsecond:secondViewController = (segue.destination as? secondViewController)!
            let objsecond = segue.destination as? secondViewController
            objsecond?.second = "Teacher"
        }else if segue.identifier == "seguestudent"
        {
            let objthired:thiredViewController = (segue.destination as? thiredViewController)!
            objthired.thired = "student"
        }else if segue.identifier == "seguestuff"
        {
            let objfour:fourViewController = (segue.destination as? fourViewController)!
            objfour.four = "Staff"
        }
        
    }
}

