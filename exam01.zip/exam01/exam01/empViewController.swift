//
//  empViewController.swift
//  exam01
//
//  Created by agile-10 on 24/08/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class empViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet var tblinfo:UITableView!
    
    var info:[[String:String]] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.ragister(withfname: "gopi", withlname: "rathod", withcity: "botad", withstate: "gujrat", withcontry: "india", withblood: "o+", withmonum: "875454654456", withhomenum: "5865645", withdesi: "aghjfrsegfrhjs", withabout: "fhjdghfdghj")
        
        print(info)
        
        self.tblinfo.dataSource = self
        self.tblinfo.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func ragister(withfname fname:String,withlname lname:String,withcity city:String,withstate state:String,withcontry contry:String,withblood blood:String,withmonum monum:String,withhomenum homenum:String,withdesi desi:String,withabout about:String){
        
        let data:[String:String] = ["fnaem":fname,"lname":lname,"city":city,"state":state,"contry":contry,"blood":blood,"monum":monum,"homenum":homenum,"desi":desi,"about":about,"id":"\(info.count+1)"]
        
        info.append(data)
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return info.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
      let cell:dataTableViewCell = tableView.dequeueReusableCell(withIdentifier: "dataTableViewCell") as! dataTableViewCell 
        
        var obj:[String:String] = self.info[indexPath.row]
        cell.fnm.text = obj["fname"]
        return cell
    
        
        
    }
    

  
}
