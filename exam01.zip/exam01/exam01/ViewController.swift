//
//  ViewController.swift
//  exam01
//
//  Created by agile-10 on 24/08/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var tblview:UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        let btn:UIButton = UIButton.init(type: .infoDark)
        let rightbar:UIBarButtonItem = UIBarButtonItem.init(customView: btn)
        self.navigationItem.rightBarButtonItem = rightbar
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

