//
//  dataTableViewCell.swift
//  exam01
//
//  Created by agile-10 on 24/08/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class dataTableViewCell: UITableViewCell {
    
     @IBOutlet var fnm:UITextField!
     /*@IBOutlet var lname:UITextField!
     @IBOutlet var city:UITextField!
     @IBOutlet var state:UITextField!
     @IBOutlet var country:UITextField!
     @IBOutlet var bloodgrp:UITextField!
     @IBOutlet var monum:UITextField!
     @IBOutlet var homenum:UITextField!
     @IBOutlet var designation:UITextField!
     @IBOutlet var about:UITextField!*/
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
