//
//  ViewController.swift
//  Gestures
//
//  Created by agile-10 on 28/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var image:UIImageView!
    var swipeGesture:UISwipeGestureRecognizer!
    
    var firstxl:CGFloat = 0.0
    var firstyl:CGFloat = 0.0

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let objpinchGesture = UIPinchGestureRecognizer.init(target: self, action: #selector(ViewController.pinchGesture(_:)))
        image.backgroundColor = UIColor.red
        image.addGestureRecognizer(objpinchGesture)
        
        let objrotetGesture = UIRotationGestureRecognizer.init(target: self, action: #selector(rotetGesture(_:)))
        image.addGestureRecognizer(objrotetGesture)
        
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(tapGesture(_:)))
        
        image.addGestureRecognizer(tapGesture)
        
        let longPresGesture = UILongPressGestureRecognizer.init(target: self, action: #selector(longPressGesture(_:)))
        image.addGestureRecognizer(longPresGesture)
        
         swipeGesture = UISwipeGestureRecognizer.init(target: self, action: #selector(swipeGesture(_:)))
        swipeGesture.direction = .left
        self.view.addGestureRecognizer(swipeGesture)
        
        swipeGesture = UISwipeGestureRecognizer.init(target: self, action: #selector(swipeGesture(_:)))
        swipeGesture.direction = .right
        self.view.addGestureRecognizer(swipeGesture)
        
        
        let panGesture = UIPanGestureRecognizer.init(target: self, action: #selector(panGesture(_:)))
        image.addGestureRecognizer(panGesture)

        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func pinchGesture(_ recognizer: UIPinchGestureRecognizer){
        
        // zoom in and zoom out
        print(recognizer.scale)
        recognizer.view?.transform = (recognizer.view?.transform.scaledBy(x: recognizer.scale, y: recognizer.scale))!
        recognizer.scale = 1
        
    }
    
    @IBAction func rotetGesture(_ recognizer: UIRotationGestureRecognizer){
        print(recognizer.rotation)
        recognizer.view?.transform = (recognizer.view?.transform.rotated(by: recognizer.rotation))!
        recognizer.rotation = 0
    }
    
    @IBAction func tapGesture(_ sender: UITapGestureRecognizer){
        print("taped")
    }
    
    @IBAction func longPressGesture(_ sender: UILongPressGestureRecognizer){
        print("long Press")
        
    }
    
    @IBAction func swipeGesture(_ sender: UISwipeGestureRecognizer){
        
        
            if sender.direction == .left{
                image.isHidden = true
            }else{
                image.isHidden = false
            }

      
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer){
        // move image
        print("move")
        var transletorpoint:CGPoint = sender.translation(in: view)
        
        if sender.state == .began{
            firstxl = (sender.view?.center.x)!
            firstyl = (sender.view?.center.y)!
        }
        transletorpoint = CGPoint.init(x: firstxl + transletorpoint.x, y: firstyl + transletorpoint.y)
        
        sender.view?.center = transletorpoint
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

